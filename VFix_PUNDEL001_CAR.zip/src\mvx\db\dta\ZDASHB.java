/*
DB-generator version: 12.4.2
*/
package mvx.db.dta;

import mvx.db.common.*;
import mvx.util.MvxString;
import mvx.util.MvxRecord;

public class ZDASHB extends GenericMDB
{
	// Physical table name
	public String[] Table = { "ZDASHB","ZDASHB"};

	//Logic files
	final static String[] LFs = {"RR","00"};

	//mapper for LFs
	public int[] pos = { 0, 0};

	class Inst {
		byte[] loadedRec = new byte[720];
		byte[] control = new byte[35];

		private MvxRecord[][] keyRecord = {
		new MvxRecord[4], new MvxRecord[4]
		};
		byte[] lengthOfBLOB=new byte[4];
		// Public variables database buffer fields
		protected int CONO,RGDT,RGTM,LMDT,CHNO;
		protected long LMTS;
		protected MvxString DIVI = null,SUNO = null,SUNM = null,ROUT = null,TX40 = null,WHLO = null,WHNM = null,TRCA = null,TX402 = null,BANO = null,ATVA = null,FTVA = null,FSVA = null,DTVA = null,DOVA = null,UDF1 = null,CHID = null;
			protected double ATVN,TRQT,KTVN,KETN,KTV1,KTV2,RTVN,LTVN,LRQT,DRQT,TTQT;
		
	}
	transient Inst inst=null;
	private void ensureInst()
	{
		if(inst==null){
			inst = new Inst();
		}
	}

	public ZDASHB()
	{
		init( Table, LFs, pos, record, mvx.db.def.dZDASHB.dbPool, false);
		System.arraycopy(clearedBuffer, 0, record[0].buffer, 0, 720);
	}

	public void reset()
	{
		super.reset();
		init( Table, LFs, pos, record, mvx.db.def.dZDASHB.dbPool, false);
	}

	public void clear()
	{
		super.clear();
		System.arraycopy(clearedBuffer, 0, record[0].buffer, 0, 720);
			if(inst!=null){		for(int i=0;i<34;i++)
				inst.control[i]=0;
		}
	}

	public void freeResources()
	{
		super.freeResources();
		inst=null;
	}

	public void clearNOKEY(String LF)
	{
		ensureInst();
		if ( LF.equals( "RR"))
		{
			getCONO();
			getSUNO();
			getBANO();
			System.arraycopy(clearedBuffer, 0, record[0].buffer, 0, 720);
			for(int i=0;i<34;i++)
				inst.control[i]=0;
			inst.control[0]=2;
			inst.control[2]=2;
			inst.control[10]=2;
		}
		else if ( LF.equals( "00"))
		{
			getCONO();
			getSUNO();
			getBANO();
			System.arraycopy(clearedBuffer, 0, record[0].buffer, 0, 720);
			for(int i=0;i<34;i++)
				inst.control[i]=0;
			inst.control[0]=2;
			inst.control[2]=2;
			inst.control[10]=2;
		}
			}

	public boolean CHCOok(){return true;}

	// shall look at BL.date
	public boolean isQualifiedForSLF() { return true;}

	//Get:ers & Set:ers
	public int getCONO(){
		ensureInst();
		if(inst.control[0]==0){
			inst.control[0]=1;
			record[0].bufferPointer = 0;
			inst.CONO = record[0].getInt(3);
		}
		return inst.CONO;
	}
	public MvxString getDIVI(){
		ensureInst();
		if(inst.DIVI==null){
			inst.DIVI=new MvxString(3);
		}
		if(inst.control[1]==0){
			inst.control[1]=1;
			record[0].bufferPointer = 2;
			record[0].getString(inst.DIVI);
		}
		return inst.DIVI;
	}
	public MvxString getSUNO(){
		ensureInst();
		if(inst.SUNO==null){
			inst.SUNO=new MvxString(10);
		}
		if(inst.control[2]==0){
			inst.control[2]=1;
			record[0].bufferPointer = 8;
			record[0].getString(inst.SUNO);
		}
		return inst.SUNO;
	}
	public MvxString getSUNM(){
		ensureInst();
		if(inst.SUNM==null){
			inst.SUNM=new MvxString(36);
		}
		if(inst.control[3]==0){
			inst.control[3]=1;
			record[0].bufferPointer = 28;
			record[0].getString(inst.SUNM);
		}
		return inst.SUNM;
	}
	public MvxString getROUT(){
		ensureInst();
		if(inst.ROUT==null){
			inst.ROUT=new MvxString(6);
		}
		if(inst.control[4]==0){
			inst.control[4]=1;
			record[0].bufferPointer = 100;
			record[0].getString(inst.ROUT);
		}
		return inst.ROUT;
	}
	public MvxString getTX40(){
		ensureInst();
		if(inst.TX40==null){
			inst.TX40=new MvxString(40);
		}
		if(inst.control[5]==0){
			inst.control[5]=1;
			record[0].bufferPointer = 112;
			record[0].getString(inst.TX40);
		}
		return inst.TX40;
	}
	public MvxString getWHLO(){
		ensureInst();
		if(inst.WHLO==null){
			inst.WHLO=new MvxString(3);
		}
		if(inst.control[6]==0){
			inst.control[6]=1;
			record[0].bufferPointer = 192;
			record[0].getString(inst.WHLO);
		}
		return inst.WHLO;
	}
	public MvxString getWHNM(){
		ensureInst();
		if(inst.WHNM==null){
			inst.WHNM=new MvxString(36);
		}
		if(inst.control[7]==0){
			inst.control[7]=1;
			record[0].bufferPointer = 198;
			record[0].getString(inst.WHNM);
		}
		return inst.WHNM;
	}
	public MvxString getTRCA(){
		ensureInst();
		if(inst.TRCA==null){
			inst.TRCA=new MvxString(8);
		}
		if(inst.control[8]==0){
			inst.control[8]=1;
			record[0].bufferPointer = 270;
			record[0].getString(inst.TRCA);
		}
		return inst.TRCA;
	}
	public MvxString getTX402(){
		ensureInst();
		if(inst.TX402==null){
			inst.TX402=new MvxString(40);
		}
		if(inst.control[9]==0){
			inst.control[9]=1;
			record[0].bufferPointer = 286;
			record[0].getString(inst.TX402);
		}
		return inst.TX402;
	}
	public MvxString getBANO(){
		ensureInst();
		if(inst.BANO==null){
			inst.BANO=new MvxString(20);
		}
		if(inst.control[10]==0){
			inst.control[10]=1;
			record[0].bufferPointer = 366;
			record[0].getString(inst.BANO);
		}
		return inst.BANO;
	}
	public MvxString getATVA(){
		ensureInst();
		if(inst.ATVA==null){
			inst.ATVA=new MvxString(15);
		}
		if(inst.control[11]==0){
			inst.control[11]=1;
			record[0].bufferPointer = 406;
			record[0].getString(inst.ATVA);
		}
		return inst.ATVA;
	}
	public double getATVN(){
		ensureInst();
		if(inst.control[12]==0){
			inst.control[12]=1;
			record[0].bufferPointer = 436;
			inst.ATVN = record[0].getDouble(15 ,6);
		}
			return inst.ATVN;
	}
	public double getTRQT(){
		ensureInst();
		if(inst.control[13]==0){
			inst.control[13]=1;
			record[0].bufferPointer = 444;
			inst.TRQT = record[0].getDouble(15 ,6);
		}
			return inst.TRQT;
	}
	public double getKTVN(){
		ensureInst();
		if(inst.control[14]==0){
			inst.control[14]=1;
			record[0].bufferPointer = 452;
			inst.KTVN = record[0].getDouble(15 ,6);
		}
			return inst.KTVN;
	}
	public double getKETN(){
		ensureInst();
		if(inst.control[15]==0){
			inst.control[15]=1;
			record[0].bufferPointer = 460;
			inst.KETN = record[0].getDouble(15 ,6);
		}
			return inst.KETN;
	}
	public MvxString getFTVA(){
		ensureInst();
		if(inst.FTVA==null){
			inst.FTVA=new MvxString(15);
		}
		if(inst.control[16]==0){
			inst.control[16]=1;
			record[0].bufferPointer = 468;
			record[0].getString(inst.FTVA);
		}
		return inst.FTVA;
	}
	public MvxString getFSVA(){
		ensureInst();
		if(inst.FSVA==null){
			inst.FSVA=new MvxString(15);
		}
		if(inst.control[17]==0){
			inst.control[17]=1;
			record[0].bufferPointer = 498;
			record[0].getString(inst.FSVA);
		}
		return inst.FSVA;
	}
	public double getKTV1(){
		ensureInst();
		if(inst.control[18]==0){
			inst.control[18]=1;
			record[0].bufferPointer = 528;
			inst.KTV1 = record[0].getDouble(15 ,6);
		}
			return inst.KTV1;
	}
	public double getKTV2(){
		ensureInst();
		if(inst.control[19]==0){
			inst.control[19]=1;
			record[0].bufferPointer = 536;
			inst.KTV2 = record[0].getDouble(15 ,6);
		}
			return inst.KTV2;
	}
	public double getRTVN(){
		ensureInst();
		if(inst.control[20]==0){
			inst.control[20]=1;
			record[0].bufferPointer = 544;
			inst.RTVN = record[0].getDouble(15 ,6);
		}
			return inst.RTVN;
	}
	public double getLTVN(){
		ensureInst();
		if(inst.control[21]==0){
			inst.control[21]=1;
			record[0].bufferPointer = 552;
			inst.LTVN = record[0].getDouble(15 ,6);
		}
			return inst.LTVN;
	}
	public double getLRQT(){
		ensureInst();
		if(inst.control[22]==0){
			inst.control[22]=1;
			record[0].bufferPointer = 560;
			inst.LRQT = record[0].getDouble(15 ,6);
		}
			return inst.LRQT;
	}
	public double getDRQT(){
		ensureInst();
		if(inst.control[23]==0){
			inst.control[23]=1;
			record[0].bufferPointer = 568;
			inst.DRQT = record[0].getDouble(15 ,6);
		}
			return inst.DRQT;
	}
	public double getTTQT(){
		ensureInst();
		if(inst.control[24]==0){
			inst.control[24]=1;
			record[0].bufferPointer = 576;
			inst.TTQT = record[0].getDouble(15 ,6);
		}
			return inst.TTQT;
	}
	public MvxString getDTVA(){
		ensureInst();
		if(inst.DTVA==null){
			inst.DTVA=new MvxString(15);
		}
		if(inst.control[25]==0){
			inst.control[25]=1;
			record[0].bufferPointer = 584;
			record[0].getString(inst.DTVA);
		}
		return inst.DTVA;
	}
	public MvxString getDOVA(){
		ensureInst();
		if(inst.DOVA==null){
			inst.DOVA=new MvxString(15);
		}
		if(inst.control[26]==0){
			inst.control[26]=1;
			record[0].bufferPointer = 614;
			record[0].getString(inst.DOVA);
		}
		return inst.DOVA;
	}
	public MvxString getUDF1(){
		ensureInst();
		if(inst.UDF1==null){
			inst.UDF1=new MvxString(15);
		}
		if(inst.control[27]==0){
			inst.control[27]=1;
			record[0].bufferPointer = 644;
			record[0].getString(inst.UDF1);
		}
		return inst.UDF1;
	}
	public int getRGDT(){
		ensureInst();
		if(inst.control[28]==0){
			inst.control[28]=1;
			record[0].bufferPointer = 674;
			inst.RGDT = record[0].getInt(8);
		}
		return inst.RGDT;
	}
	public int getRGTM(){
		ensureInst();
		if(inst.control[29]==0){
			inst.control[29]=1;
			record[0].bufferPointer = 679;
			inst.RGTM = record[0].getInt(6);
		}
		return inst.RGTM;
	}
	public int getLMDT(){
		ensureInst();
		if(inst.control[30]==0){
			inst.control[30]=1;
			record[0].bufferPointer = 683;
			inst.LMDT = record[0].getInt(8);
		}
		return inst.LMDT;
	}
	public int getCHNO(){
		ensureInst();
		if(inst.control[31]==0){
			inst.control[31]=1;
			record[0].bufferPointer = 688;
			inst.CHNO = record[0].getInt(3);
		}
		return inst.CHNO;
	}
	public MvxString getCHID(){
		ensureInst();
		if(inst.CHID==null){
			inst.CHID=new MvxString(10);
		}
		if(inst.control[32]==0){
			inst.control[32]=1;
			record[0].bufferPointer = 690;
			record[0].getString(inst.CHID);
		}
		return inst.CHID;
	}
	public long getLMTS(){
		ensureInst();
		if(inst.control[33]==0){
			inst.control[33]=1;
			record[0].bufferPointer = 710;
			inst.LMTS = record[0].getLong(18);
		}
			return inst.LMTS;
	}
	public void setCONO( int value){
		if(getCONO()!=value){
			inst.control[0]=2;
			inst.CONO = value;
		}
	}
	public MvxString setDIVI(){
		getDIVI();
		inst.control[1]=2;
		return inst.DIVI;
	}
	public MvxString setSUNO(){
		getSUNO();
		inst.control[2]=2;
		return inst.SUNO;
	}
	public MvxString setSUNM(){
		getSUNM();
		inst.control[3]=2;
		return inst.SUNM;
	}
	public MvxString setROUT(){
		getROUT();
		inst.control[4]=2;
		return inst.ROUT;
	}
	public MvxString setTX40(){
		getTX40();
		inst.control[5]=2;
		return inst.TX40;
	}
	public MvxString setWHLO(){
		getWHLO();
		inst.control[6]=2;
		return inst.WHLO;
	}
	public MvxString setWHNM(){
		getWHNM();
		inst.control[7]=2;
		return inst.WHNM;
	}
	public MvxString setTRCA(){
		getTRCA();
		inst.control[8]=2;
		return inst.TRCA;
	}
	public MvxString setTX402(){
		getTX402();
		inst.control[9]=2;
		return inst.TX402;
	}
	public MvxString setBANO(){
		getBANO();
		inst.control[10]=2;
		return inst.BANO;
	}
	public MvxString setATVA(){
		getATVA();
		inst.control[11]=2;
		return inst.ATVA;
	}
	public void setATVN( double value){
		if(getATVN()!=value){
		inst.control[12]=2;
			inst.ATVN = value;
		}
	}
	public void setTRQT( double value){
		if(getTRQT()!=value){
		inst.control[13]=2;
			inst.TRQT = value;
		}
	}
	public void setKTVN( double value){
		if(getKTVN()!=value){
		inst.control[14]=2;
			inst.KTVN = value;
		}
	}
	public void setKETN( double value){
		if(getKETN()!=value){
		inst.control[15]=2;
			inst.KETN = value;
		}
	}
	public MvxString setFTVA(){
		getFTVA();
		inst.control[16]=2;
		return inst.FTVA;
	}
	public MvxString setFSVA(){
		getFSVA();
		inst.control[17]=2;
		return inst.FSVA;
	}
	public void setKTV1( double value){
		if(getKTV1()!=value){
		inst.control[18]=2;
			inst.KTV1 = value;
		}
	}
	public void setKTV2( double value){
		if(getKTV2()!=value){
		inst.control[19]=2;
			inst.KTV2 = value;
		}
	}
	public void setRTVN( double value){
		if(getRTVN()!=value){
		inst.control[20]=2;
			inst.RTVN = value;
		}
	}
	public void setLTVN( double value){
		if(getLTVN()!=value){
		inst.control[21]=2;
			inst.LTVN = value;
		}
	}
	public void setLRQT( double value){
		if(getLRQT()!=value){
		inst.control[22]=2;
			inst.LRQT = value;
		}
	}
	public void setDRQT( double value){
		if(getDRQT()!=value){
		inst.control[23]=2;
			inst.DRQT = value;
		}
	}
	public void setTTQT( double value){
		if(getTTQT()!=value){
		inst.control[24]=2;
			inst.TTQT = value;
		}
	}
	public MvxString setDTVA(){
		getDTVA();
		inst.control[25]=2;
		return inst.DTVA;
	}
	public MvxString setDOVA(){
		getDOVA();
		inst.control[26]=2;
		return inst.DOVA;
	}
	public MvxString setUDF1(){
		getUDF1();
		inst.control[27]=2;
		return inst.UDF1;
	}
	public void setRGDT( int value){
		if(getRGDT()!=value){
			inst.control[28]=2;
			inst.RGDT = value;
		}
	}
	public void setRGTM( int value){
		if(getRGTM()!=value){
			inst.control[29]=2;
			inst.RGTM = value;
		}
	}
	public void setLMDT( int value){
		if(getLMDT()!=value){
			inst.control[30]=2;
			inst.LMDT = value;
		}
	}
	public void setCHNO( int value){
		if(getCHNO()!=value){
			inst.control[31]=2;
			inst.CHNO = value;
		}
	}
	public MvxString setCHID(){
		getCHID();
		inst.control[32]=2;
		return inst.CHID;
	}
	public void setLMTS( long value){
		if(getLMTS()!=value){
			inst.control[33]=2;
			inst.LMTS = value;
		}
	}

	//dummy for RGTM & RGDT
	public String toString(){
		return getClass().getName();
	}

	//MvxRecord description of all fields
	private  MvxRecord[] record = {new MvxRecord( 720)};

	public MvxRecord getContents( int LF) {
		if(inst==null) {
			System.arraycopy( clearedBuffer, 0, record[0].buffer, 0, 720);
			return record[0];
		}
		char a;
		byte[] buff = record[0].buffer;
		int LFdummy = LF;//Only used in join cases
		int i;
		long j;
		long l;
		//inst.CONO {2, 3, 0}
		if(inst.control[0]==2){
			if( inst.CONO<0)
			{
				i = ( -inst.CONO)%1000;
				buff[1] = ( byte)( ( ( i%10)<<4) | 0xd);
			}
			else
			{
				i = inst.CONO%1000;
			buff[1] = ( byte)( ( ( i%10)<<4) | 0xf);
			}
			i/=10;
			buff[0] = ( byte)( ( i%10) | ( ( i/10) << 4));
		}
		//inst.DIVI {6, 3, 0}
		if(inst.control[1]==2){
			buff[2] = ( byte) ( (a=inst.DIVI.value[0])>>8);
			buff[3] = ( byte) (a);
			buff[4] = ( byte) ( (a=inst.DIVI.value[1])>>8);
			buff[5] = ( byte) (a);
			buff[6] = ( byte) ( (a=inst.DIVI.value[2])>>8);
			buff[7] = ( byte) (a);

			inst.control[1]=1;
			for (int k = 2; k < 8; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[1]=3;
					break;
				}
			}
		}
		//inst.SUNO {20, 10, 0}
		if(inst.control[2]==2){
			buff[8] = ( byte) ( (a=inst.SUNO.value[0])>>8);
			buff[9] = ( byte) (a);
			buff[10] = ( byte) ( (a=inst.SUNO.value[1])>>8);
			buff[11] = ( byte) (a);
			buff[12] = ( byte) ( (a=inst.SUNO.value[2])>>8);
			buff[13] = ( byte) (a);
			buff[14] = ( byte) ( (a=inst.SUNO.value[3])>>8);
			buff[15] = ( byte) (a);
			buff[16] = ( byte) ( (a=inst.SUNO.value[4])>>8);
			buff[17] = ( byte) (a);
			buff[18] = ( byte) ( (a=inst.SUNO.value[5])>>8);
			buff[19] = ( byte) (a);
			buff[20] = ( byte) ( (a=inst.SUNO.value[6])>>8);
			buff[21] = ( byte) (a);
			buff[22] = ( byte) ( (a=inst.SUNO.value[7])>>8);
			buff[23] = ( byte) (a);
			buff[24] = ( byte) ( (a=inst.SUNO.value[8])>>8);
			buff[25] = ( byte) (a);
			buff[26] = ( byte) ( (a=inst.SUNO.value[9])>>8);
			buff[27] = ( byte) (a);

			inst.control[2]=1;
			for (int k = 8; k < 28; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[2]=3;
					break;
				}
			}
		}
		//inst.SUNM {72, 36, 0}
		if(inst.control[3]==2){
			buff[28] = ( byte) ( (a=inst.SUNM.value[0])>>8);
			buff[29] = ( byte) (a);
			buff[30] = ( byte) ( (a=inst.SUNM.value[1])>>8);
			buff[31] = ( byte) (a);
			buff[32] = ( byte) ( (a=inst.SUNM.value[2])>>8);
			buff[33] = ( byte) (a);
			buff[34] = ( byte) ( (a=inst.SUNM.value[3])>>8);
			buff[35] = ( byte) (a);
			buff[36] = ( byte) ( (a=inst.SUNM.value[4])>>8);
			buff[37] = ( byte) (a);
			buff[38] = ( byte) ( (a=inst.SUNM.value[5])>>8);
			buff[39] = ( byte) (a);
			buff[40] = ( byte) ( (a=inst.SUNM.value[6])>>8);
			buff[41] = ( byte) (a);
			buff[42] = ( byte) ( (a=inst.SUNM.value[7])>>8);
			buff[43] = ( byte) (a);
			buff[44] = ( byte) ( (a=inst.SUNM.value[8])>>8);
			buff[45] = ( byte) (a);
			buff[46] = ( byte) ( (a=inst.SUNM.value[9])>>8);
			buff[47] = ( byte) (a);
			buff[48] = ( byte) ( (a=inst.SUNM.value[10])>>8);
			buff[49] = ( byte) (a);
			buff[50] = ( byte) ( (a=inst.SUNM.value[11])>>8);
			buff[51] = ( byte) (a);
			buff[52] = ( byte) ( (a=inst.SUNM.value[12])>>8);
			buff[53] = ( byte) (a);
			buff[54] = ( byte) ( (a=inst.SUNM.value[13])>>8);
			buff[55] = ( byte) (a);
			buff[56] = ( byte) ( (a=inst.SUNM.value[14])>>8);
			buff[57] = ( byte) (a);
			buff[58] = ( byte) ( (a=inst.SUNM.value[15])>>8);
			buff[59] = ( byte) (a);
			buff[60] = ( byte) ( (a=inst.SUNM.value[16])>>8);
			buff[61] = ( byte) (a);
			buff[62] = ( byte) ( (a=inst.SUNM.value[17])>>8);
			buff[63] = ( byte) (a);
			buff[64] = ( byte) ( (a=inst.SUNM.value[18])>>8);
			buff[65] = ( byte) (a);
			buff[66] = ( byte) ( (a=inst.SUNM.value[19])>>8);
			buff[67] = ( byte) (a);
			buff[68] = ( byte) ( (a=inst.SUNM.value[20])>>8);
			buff[69] = ( byte) (a);
			buff[70] = ( byte) ( (a=inst.SUNM.value[21])>>8);
			buff[71] = ( byte) (a);
			buff[72] = ( byte) ( (a=inst.SUNM.value[22])>>8);
			buff[73] = ( byte) (a);
			buff[74] = ( byte) ( (a=inst.SUNM.value[23])>>8);
			buff[75] = ( byte) (a);
			buff[76] = ( byte) ( (a=inst.SUNM.value[24])>>8);
			buff[77] = ( byte) (a);
			buff[78] = ( byte) ( (a=inst.SUNM.value[25])>>8);
			buff[79] = ( byte) (a);
			buff[80] = ( byte) ( (a=inst.SUNM.value[26])>>8);
			buff[81] = ( byte) (a);
			buff[82] = ( byte) ( (a=inst.SUNM.value[27])>>8);
			buff[83] = ( byte) (a);
			buff[84] = ( byte) ( (a=inst.SUNM.value[28])>>8);
			buff[85] = ( byte) (a);
			buff[86] = ( byte) ( (a=inst.SUNM.value[29])>>8);
			buff[87] = ( byte) (a);
			buff[88] = ( byte) ( (a=inst.SUNM.value[30])>>8);
			buff[89] = ( byte) (a);
			buff[90] = ( byte) ( (a=inst.SUNM.value[31])>>8);
			buff[91] = ( byte) (a);
			buff[92] = ( byte) ( (a=inst.SUNM.value[32])>>8);
			buff[93] = ( byte) (a);
			buff[94] = ( byte) ( (a=inst.SUNM.value[33])>>8);
			buff[95] = ( byte) (a);
			buff[96] = ( byte) ( (a=inst.SUNM.value[34])>>8);
			buff[97] = ( byte) (a);
			buff[98] = ( byte) ( (a=inst.SUNM.value[35])>>8);
			buff[99] = ( byte) (a);

			inst.control[3]=1;
			for (int k = 28; k < 100; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[3]=3;
					break;
				}
			}
		}
		//inst.ROUT {12, 6, 0}
		if(inst.control[4]==2){
			buff[100] = ( byte) ( (a=inst.ROUT.value[0])>>8);
			buff[101] = ( byte) (a);
			buff[102] = ( byte) ( (a=inst.ROUT.value[1])>>8);
			buff[103] = ( byte) (a);
			buff[104] = ( byte) ( (a=inst.ROUT.value[2])>>8);
			buff[105] = ( byte) (a);
			buff[106] = ( byte) ( (a=inst.ROUT.value[3])>>8);
			buff[107] = ( byte) (a);
			buff[108] = ( byte) ( (a=inst.ROUT.value[4])>>8);
			buff[109] = ( byte) (a);
			buff[110] = ( byte) ( (a=inst.ROUT.value[5])>>8);
			buff[111] = ( byte) (a);

			inst.control[4]=1;
			for (int k = 100; k < 112; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[4]=3;
					break;
				}
			}
		}
		//inst.TX40 {80, 40, 0}
		if(inst.control[5]==2){
			buff[112] = ( byte) ( (a=inst.TX40.value[0])>>8);
			buff[113] = ( byte) (a);
			buff[114] = ( byte) ( (a=inst.TX40.value[1])>>8);
			buff[115] = ( byte) (a);
			buff[116] = ( byte) ( (a=inst.TX40.value[2])>>8);
			buff[117] = ( byte) (a);
			buff[118] = ( byte) ( (a=inst.TX40.value[3])>>8);
			buff[119] = ( byte) (a);
			buff[120] = ( byte) ( (a=inst.TX40.value[4])>>8);
			buff[121] = ( byte) (a);
			buff[122] = ( byte) ( (a=inst.TX40.value[5])>>8);
			buff[123] = ( byte) (a);
			buff[124] = ( byte) ( (a=inst.TX40.value[6])>>8);
			buff[125] = ( byte) (a);
			buff[126] = ( byte) ( (a=inst.TX40.value[7])>>8);
			buff[127] = ( byte) (a);
			buff[128] = ( byte) ( (a=inst.TX40.value[8])>>8);
			buff[129] = ( byte) (a);
			buff[130] = ( byte) ( (a=inst.TX40.value[9])>>8);
			buff[131] = ( byte) (a);
			buff[132] = ( byte) ( (a=inst.TX40.value[10])>>8);
			buff[133] = ( byte) (a);
			buff[134] = ( byte) ( (a=inst.TX40.value[11])>>8);
			buff[135] = ( byte) (a);
			buff[136] = ( byte) ( (a=inst.TX40.value[12])>>8);
			buff[137] = ( byte) (a);
			buff[138] = ( byte) ( (a=inst.TX40.value[13])>>8);
			buff[139] = ( byte) (a);
			buff[140] = ( byte) ( (a=inst.TX40.value[14])>>8);
			buff[141] = ( byte) (a);
			buff[142] = ( byte) ( (a=inst.TX40.value[15])>>8);
			buff[143] = ( byte) (a);
			buff[144] = ( byte) ( (a=inst.TX40.value[16])>>8);
			buff[145] = ( byte) (a);
			buff[146] = ( byte) ( (a=inst.TX40.value[17])>>8);
			buff[147] = ( byte) (a);
			buff[148] = ( byte) ( (a=inst.TX40.value[18])>>8);
			buff[149] = ( byte) (a);
			buff[150] = ( byte) ( (a=inst.TX40.value[19])>>8);
			buff[151] = ( byte) (a);
			buff[152] = ( byte) ( (a=inst.TX40.value[20])>>8);
			buff[153] = ( byte) (a);
			buff[154] = ( byte) ( (a=inst.TX40.value[21])>>8);
			buff[155] = ( byte) (a);
			buff[156] = ( byte) ( (a=inst.TX40.value[22])>>8);
			buff[157] = ( byte) (a);
			buff[158] = ( byte) ( (a=inst.TX40.value[23])>>8);
			buff[159] = ( byte) (a);
			buff[160] = ( byte) ( (a=inst.TX40.value[24])>>8);
			buff[161] = ( byte) (a);
			buff[162] = ( byte) ( (a=inst.TX40.value[25])>>8);
			buff[163] = ( byte) (a);
			buff[164] = ( byte) ( (a=inst.TX40.value[26])>>8);
			buff[165] = ( byte) (a);
			buff[166] = ( byte) ( (a=inst.TX40.value[27])>>8);
			buff[167] = ( byte) (a);
			buff[168] = ( byte) ( (a=inst.TX40.value[28])>>8);
			buff[169] = ( byte) (a);
			buff[170] = ( byte) ( (a=inst.TX40.value[29])>>8);
			buff[171] = ( byte) (a);
			buff[172] = ( byte) ( (a=inst.TX40.value[30])>>8);
			buff[173] = ( byte) (a);
			buff[174] = ( byte) ( (a=inst.TX40.value[31])>>8);
			buff[175] = ( byte) (a);
			buff[176] = ( byte) ( (a=inst.TX40.value[32])>>8);
			buff[177] = ( byte) (a);
			buff[178] = ( byte) ( (a=inst.TX40.value[33])>>8);
			buff[179] = ( byte) (a);
			buff[180] = ( byte) ( (a=inst.TX40.value[34])>>8);
			buff[181] = ( byte) (a);
			buff[182] = ( byte) ( (a=inst.TX40.value[35])>>8);
			buff[183] = ( byte) (a);
			buff[184] = ( byte) ( (a=inst.TX40.value[36])>>8);
			buff[185] = ( byte) (a);
			buff[186] = ( byte) ( (a=inst.TX40.value[37])>>8);
			buff[187] = ( byte) (a);
			buff[188] = ( byte) ( (a=inst.TX40.value[38])>>8);
			buff[189] = ( byte) (a);
			buff[190] = ( byte) ( (a=inst.TX40.value[39])>>8);
			buff[191] = ( byte) (a);

			inst.control[5]=1;
			for (int k = 112; k < 192; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[5]=3;
					break;
				}
			}
		}
		//inst.WHLO {6, 3, 0}
		if(inst.control[6]==2){
			buff[192] = ( byte) ( (a=inst.WHLO.value[0])>>8);
			buff[193] = ( byte) (a);
			buff[194] = ( byte) ( (a=inst.WHLO.value[1])>>8);
			buff[195] = ( byte) (a);
			buff[196] = ( byte) ( (a=inst.WHLO.value[2])>>8);
			buff[197] = ( byte) (a);

			inst.control[6]=1;
			for (int k = 192; k < 198; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[6]=3;
					break;
				}
			}
		}
		//inst.WHNM {72, 36, 0}
		if(inst.control[7]==2){
			buff[198] = ( byte) ( (a=inst.WHNM.value[0])>>8);
			buff[199] = ( byte) (a);
			buff[200] = ( byte) ( (a=inst.WHNM.value[1])>>8);
			buff[201] = ( byte) (a);
			buff[202] = ( byte) ( (a=inst.WHNM.value[2])>>8);
			buff[203] = ( byte) (a);
			buff[204] = ( byte) ( (a=inst.WHNM.value[3])>>8);
			buff[205] = ( byte) (a);
			buff[206] = ( byte) ( (a=inst.WHNM.value[4])>>8);
			buff[207] = ( byte) (a);
			buff[208] = ( byte) ( (a=inst.WHNM.value[5])>>8);
			buff[209] = ( byte) (a);
			buff[210] = ( byte) ( (a=inst.WHNM.value[6])>>8);
			buff[211] = ( byte) (a);
			buff[212] = ( byte) ( (a=inst.WHNM.value[7])>>8);
			buff[213] = ( byte) (a);
			buff[214] = ( byte) ( (a=inst.WHNM.value[8])>>8);
			buff[215] = ( byte) (a);
			buff[216] = ( byte) ( (a=inst.WHNM.value[9])>>8);
			buff[217] = ( byte) (a);
			buff[218] = ( byte) ( (a=inst.WHNM.value[10])>>8);
			buff[219] = ( byte) (a);
			buff[220] = ( byte) ( (a=inst.WHNM.value[11])>>8);
			buff[221] = ( byte) (a);
			buff[222] = ( byte) ( (a=inst.WHNM.value[12])>>8);
			buff[223] = ( byte) (a);
			buff[224] = ( byte) ( (a=inst.WHNM.value[13])>>8);
			buff[225] = ( byte) (a);
			buff[226] = ( byte) ( (a=inst.WHNM.value[14])>>8);
			buff[227] = ( byte) (a);
			buff[228] = ( byte) ( (a=inst.WHNM.value[15])>>8);
			buff[229] = ( byte) (a);
			buff[230] = ( byte) ( (a=inst.WHNM.value[16])>>8);
			buff[231] = ( byte) (a);
			buff[232] = ( byte) ( (a=inst.WHNM.value[17])>>8);
			buff[233] = ( byte) (a);
			buff[234] = ( byte) ( (a=inst.WHNM.value[18])>>8);
			buff[235] = ( byte) (a);
			buff[236] = ( byte) ( (a=inst.WHNM.value[19])>>8);
			buff[237] = ( byte) (a);
			buff[238] = ( byte) ( (a=inst.WHNM.value[20])>>8);
			buff[239] = ( byte) (a);
			buff[240] = ( byte) ( (a=inst.WHNM.value[21])>>8);
			buff[241] = ( byte) (a);
			buff[242] = ( byte) ( (a=inst.WHNM.value[22])>>8);
			buff[243] = ( byte) (a);
			buff[244] = ( byte) ( (a=inst.WHNM.value[23])>>8);
			buff[245] = ( byte) (a);
			buff[246] = ( byte) ( (a=inst.WHNM.value[24])>>8);
			buff[247] = ( byte) (a);
			buff[248] = ( byte) ( (a=inst.WHNM.value[25])>>8);
			buff[249] = ( byte) (a);
			buff[250] = ( byte) ( (a=inst.WHNM.value[26])>>8);
			buff[251] = ( byte) (a);
			buff[252] = ( byte) ( (a=inst.WHNM.value[27])>>8);
			buff[253] = ( byte) (a);
			buff[254] = ( byte) ( (a=inst.WHNM.value[28])>>8);
			buff[255] = ( byte) (a);
			buff[256] = ( byte) ( (a=inst.WHNM.value[29])>>8);
			buff[257] = ( byte) (a);
			buff[258] = ( byte) ( (a=inst.WHNM.value[30])>>8);
			buff[259] = ( byte) (a);
			buff[260] = ( byte) ( (a=inst.WHNM.value[31])>>8);
			buff[261] = ( byte) (a);
			buff[262] = ( byte) ( (a=inst.WHNM.value[32])>>8);
			buff[263] = ( byte) (a);
			buff[264] = ( byte) ( (a=inst.WHNM.value[33])>>8);
			buff[265] = ( byte) (a);
			buff[266] = ( byte) ( (a=inst.WHNM.value[34])>>8);
			buff[267] = ( byte) (a);
			buff[268] = ( byte) ( (a=inst.WHNM.value[35])>>8);
			buff[269] = ( byte) (a);

			inst.control[7]=1;
			for (int k = 198; k < 270; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[7]=3;
					break;
				}
			}
		}
		//inst.TRCA {16, 8, 0}
		if(inst.control[8]==2){
			buff[270] = ( byte) ( (a=inst.TRCA.value[0])>>8);
			buff[271] = ( byte) (a);
			buff[272] = ( byte) ( (a=inst.TRCA.value[1])>>8);
			buff[273] = ( byte) (a);
			buff[274] = ( byte) ( (a=inst.TRCA.value[2])>>8);
			buff[275] = ( byte) (a);
			buff[276] = ( byte) ( (a=inst.TRCA.value[3])>>8);
			buff[277] = ( byte) (a);
			buff[278] = ( byte) ( (a=inst.TRCA.value[4])>>8);
			buff[279] = ( byte) (a);
			buff[280] = ( byte) ( (a=inst.TRCA.value[5])>>8);
			buff[281] = ( byte) (a);
			buff[282] = ( byte) ( (a=inst.TRCA.value[6])>>8);
			buff[283] = ( byte) (a);
			buff[284] = ( byte) ( (a=inst.TRCA.value[7])>>8);
			buff[285] = ( byte) (a);

			inst.control[8]=1;
			for (int k = 270; k < 286; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[8]=3;
					break;
				}
			}
		}
		//inst.TX402 {80, 40, 0}
		if(inst.control[9]==2){
			buff[286] = ( byte) ( (a=inst.TX402.value[0])>>8);
			buff[287] = ( byte) (a);
			buff[288] = ( byte) ( (a=inst.TX402.value[1])>>8);
			buff[289] = ( byte) (a);
			buff[290] = ( byte) ( (a=inst.TX402.value[2])>>8);
			buff[291] = ( byte) (a);
			buff[292] = ( byte) ( (a=inst.TX402.value[3])>>8);
			buff[293] = ( byte) (a);
			buff[294] = ( byte) ( (a=inst.TX402.value[4])>>8);
			buff[295] = ( byte) (a);
			buff[296] = ( byte) ( (a=inst.TX402.value[5])>>8);
			buff[297] = ( byte) (a);
			buff[298] = ( byte) ( (a=inst.TX402.value[6])>>8);
			buff[299] = ( byte) (a);
			buff[300] = ( byte) ( (a=inst.TX402.value[7])>>8);
			buff[301] = ( byte) (a);
			buff[302] = ( byte) ( (a=inst.TX402.value[8])>>8);
			buff[303] = ( byte) (a);
			buff[304] = ( byte) ( (a=inst.TX402.value[9])>>8);
			buff[305] = ( byte) (a);
			buff[306] = ( byte) ( (a=inst.TX402.value[10])>>8);
			buff[307] = ( byte) (a);
			buff[308] = ( byte) ( (a=inst.TX402.value[11])>>8);
			buff[309] = ( byte) (a);
			buff[310] = ( byte) ( (a=inst.TX402.value[12])>>8);
			buff[311] = ( byte) (a);
			buff[312] = ( byte) ( (a=inst.TX402.value[13])>>8);
			buff[313] = ( byte) (a);
			buff[314] = ( byte) ( (a=inst.TX402.value[14])>>8);
			buff[315] = ( byte) (a);
			buff[316] = ( byte) ( (a=inst.TX402.value[15])>>8);
			buff[317] = ( byte) (a);
			buff[318] = ( byte) ( (a=inst.TX402.value[16])>>8);
			buff[319] = ( byte) (a);
			buff[320] = ( byte) ( (a=inst.TX402.value[17])>>8);
			buff[321] = ( byte) (a);
			buff[322] = ( byte) ( (a=inst.TX402.value[18])>>8);
			buff[323] = ( byte) (a);
			buff[324] = ( byte) ( (a=inst.TX402.value[19])>>8);
			buff[325] = ( byte) (a);
			buff[326] = ( byte) ( (a=inst.TX402.value[20])>>8);
			buff[327] = ( byte) (a);
			buff[328] = ( byte) ( (a=inst.TX402.value[21])>>8);
			buff[329] = ( byte) (a);
			buff[330] = ( byte) ( (a=inst.TX402.value[22])>>8);
			buff[331] = ( byte) (a);
			buff[332] = ( byte) ( (a=inst.TX402.value[23])>>8);
			buff[333] = ( byte) (a);
			buff[334] = ( byte) ( (a=inst.TX402.value[24])>>8);
			buff[335] = ( byte) (a);
			buff[336] = ( byte) ( (a=inst.TX402.value[25])>>8);
			buff[337] = ( byte) (a);
			buff[338] = ( byte) ( (a=inst.TX402.value[26])>>8);
			buff[339] = ( byte) (a);
			buff[340] = ( byte) ( (a=inst.TX402.value[27])>>8);
			buff[341] = ( byte) (a);
			buff[342] = ( byte) ( (a=inst.TX402.value[28])>>8);
			buff[343] = ( byte) (a);
			buff[344] = ( byte) ( (a=inst.TX402.value[29])>>8);
			buff[345] = ( byte) (a);
			buff[346] = ( byte) ( (a=inst.TX402.value[30])>>8);
			buff[347] = ( byte) (a);
			buff[348] = ( byte) ( (a=inst.TX402.value[31])>>8);
			buff[349] = ( byte) (a);
			buff[350] = ( byte) ( (a=inst.TX402.value[32])>>8);
			buff[351] = ( byte) (a);
			buff[352] = ( byte) ( (a=inst.TX402.value[33])>>8);
			buff[353] = ( byte) (a);
			buff[354] = ( byte) ( (a=inst.TX402.value[34])>>8);
			buff[355] = ( byte) (a);
			buff[356] = ( byte) ( (a=inst.TX402.value[35])>>8);
			buff[357] = ( byte) (a);
			buff[358] = ( byte) ( (a=inst.TX402.value[36])>>8);
			buff[359] = ( byte) (a);
			buff[360] = ( byte) ( (a=inst.TX402.value[37])>>8);
			buff[361] = ( byte) (a);
			buff[362] = ( byte) ( (a=inst.TX402.value[38])>>8);
			buff[363] = ( byte) (a);
			buff[364] = ( byte) ( (a=inst.TX402.value[39])>>8);
			buff[365] = ( byte) (a);

			inst.control[9]=1;
			for (int k = 286; k < 366; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[9]=3;
					break;
				}
			}
		}
		//inst.BANO {40, 20, 0}
		if(inst.control[10]==2){
			buff[366] = ( byte) ( (a=inst.BANO.value[0])>>8);
			buff[367] = ( byte) (a);
			buff[368] = ( byte) ( (a=inst.BANO.value[1])>>8);
			buff[369] = ( byte) (a);
			buff[370] = ( byte) ( (a=inst.BANO.value[2])>>8);
			buff[371] = ( byte) (a);
			buff[372] = ( byte) ( (a=inst.BANO.value[3])>>8);
			buff[373] = ( byte) (a);
			buff[374] = ( byte) ( (a=inst.BANO.value[4])>>8);
			buff[375] = ( byte) (a);
			buff[376] = ( byte) ( (a=inst.BANO.value[5])>>8);
			buff[377] = ( byte) (a);
			buff[378] = ( byte) ( (a=inst.BANO.value[6])>>8);
			buff[379] = ( byte) (a);
			buff[380] = ( byte) ( (a=inst.BANO.value[7])>>8);
			buff[381] = ( byte) (a);
			buff[382] = ( byte) ( (a=inst.BANO.value[8])>>8);
			buff[383] = ( byte) (a);
			buff[384] = ( byte) ( (a=inst.BANO.value[9])>>8);
			buff[385] = ( byte) (a);
			buff[386] = ( byte) ( (a=inst.BANO.value[10])>>8);
			buff[387] = ( byte) (a);
			buff[388] = ( byte) ( (a=inst.BANO.value[11])>>8);
			buff[389] = ( byte) (a);
			buff[390] = ( byte) ( (a=inst.BANO.value[12])>>8);
			buff[391] = ( byte) (a);
			buff[392] = ( byte) ( (a=inst.BANO.value[13])>>8);
			buff[393] = ( byte) (a);
			buff[394] = ( byte) ( (a=inst.BANO.value[14])>>8);
			buff[395] = ( byte) (a);
			buff[396] = ( byte) ( (a=inst.BANO.value[15])>>8);
			buff[397] = ( byte) (a);
			buff[398] = ( byte) ( (a=inst.BANO.value[16])>>8);
			buff[399] = ( byte) (a);
			buff[400] = ( byte) ( (a=inst.BANO.value[17])>>8);
			buff[401] = ( byte) (a);
			buff[402] = ( byte) ( (a=inst.BANO.value[18])>>8);
			buff[403] = ( byte) (a);
			buff[404] = ( byte) ( (a=inst.BANO.value[19])>>8);
			buff[405] = ( byte) (a);

			inst.control[10]=1;
			for (int k = 366; k < 406; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[10]=3;
					break;
				}
			}
		}
		//inst.ATVA {30, 15, 0}
		if(inst.control[11]==2){
			buff[406] = ( byte) ( (a=inst.ATVA.value[0])>>8);
			buff[407] = ( byte) (a);
			buff[408] = ( byte) ( (a=inst.ATVA.value[1])>>8);
			buff[409] = ( byte) (a);
			buff[410] = ( byte) ( (a=inst.ATVA.value[2])>>8);
			buff[411] = ( byte) (a);
			buff[412] = ( byte) ( (a=inst.ATVA.value[3])>>8);
			buff[413] = ( byte) (a);
			buff[414] = ( byte) ( (a=inst.ATVA.value[4])>>8);
			buff[415] = ( byte) (a);
			buff[416] = ( byte) ( (a=inst.ATVA.value[5])>>8);
			buff[417] = ( byte) (a);
			buff[418] = ( byte) ( (a=inst.ATVA.value[6])>>8);
			buff[419] = ( byte) (a);
			buff[420] = ( byte) ( (a=inst.ATVA.value[7])>>8);
			buff[421] = ( byte) (a);
			buff[422] = ( byte) ( (a=inst.ATVA.value[8])>>8);
			buff[423] = ( byte) (a);
			buff[424] = ( byte) ( (a=inst.ATVA.value[9])>>8);
			buff[425] = ( byte) (a);
			buff[426] = ( byte) ( (a=inst.ATVA.value[10])>>8);
			buff[427] = ( byte) (a);
			buff[428] = ( byte) ( (a=inst.ATVA.value[11])>>8);
			buff[429] = ( byte) (a);
			buff[430] = ( byte) ( (a=inst.ATVA.value[12])>>8);
			buff[431] = ( byte) (a);
			buff[432] = ( byte) ( (a=inst.ATVA.value[13])>>8);
			buff[433] = ( byte) (a);
			buff[434] = ( byte) ( (a=inst.ATVA.value[14])>>8);
			buff[435] = ( byte) (a);

			inst.control[11]=1;
			for (int k = 406; k < 436; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[11]=3;
					break;
				}
			}
		}
		//inst.ATVN {8, 15, 6}
		if(inst.control[12]==2){
				record[0].bufferPointer = 436;
				record[0].set( getATVN(), 15, 6);
		}
		//inst.TRQT {8, 15, 6}
		if(inst.control[13]==2){
				record[0].bufferPointer = 444;
				record[0].set( getTRQT(), 15, 6);
		}
		//inst.KTVN {8, 15, 6}
		if(inst.control[14]==2){
				record[0].bufferPointer = 452;
				record[0].set( getKTVN(), 15, 6);
		}
		//inst.KETN {8, 15, 6}
		if(inst.control[15]==2){
				record[0].bufferPointer = 460;
				record[0].set( getKETN(), 15, 6);
		}
		//inst.FTVA {30, 15, 0}
		if(inst.control[16]==2){
			buff[468] = ( byte) ( (a=inst.FTVA.value[0])>>8);
			buff[469] = ( byte) (a);
			buff[470] = ( byte) ( (a=inst.FTVA.value[1])>>8);
			buff[471] = ( byte) (a);
			buff[472] = ( byte) ( (a=inst.FTVA.value[2])>>8);
			buff[473] = ( byte) (a);
			buff[474] = ( byte) ( (a=inst.FTVA.value[3])>>8);
			buff[475] = ( byte) (a);
			buff[476] = ( byte) ( (a=inst.FTVA.value[4])>>8);
			buff[477] = ( byte) (a);
			buff[478] = ( byte) ( (a=inst.FTVA.value[5])>>8);
			buff[479] = ( byte) (a);
			buff[480] = ( byte) ( (a=inst.FTVA.value[6])>>8);
			buff[481] = ( byte) (a);
			buff[482] = ( byte) ( (a=inst.FTVA.value[7])>>8);
			buff[483] = ( byte) (a);
			buff[484] = ( byte) ( (a=inst.FTVA.value[8])>>8);
			buff[485] = ( byte) (a);
			buff[486] = ( byte) ( (a=inst.FTVA.value[9])>>8);
			buff[487] = ( byte) (a);
			buff[488] = ( byte) ( (a=inst.FTVA.value[10])>>8);
			buff[489] = ( byte) (a);
			buff[490] = ( byte) ( (a=inst.FTVA.value[11])>>8);
			buff[491] = ( byte) (a);
			buff[492] = ( byte) ( (a=inst.FTVA.value[12])>>8);
			buff[493] = ( byte) (a);
			buff[494] = ( byte) ( (a=inst.FTVA.value[13])>>8);
			buff[495] = ( byte) (a);
			buff[496] = ( byte) ( (a=inst.FTVA.value[14])>>8);
			buff[497] = ( byte) (a);

			inst.control[16]=1;
			for (int k = 468; k < 498; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[16]=3;
					break;
				}
			}
		}
		//inst.FSVA {30, 15, 0}
		if(inst.control[17]==2){
			buff[498] = ( byte) ( (a=inst.FSVA.value[0])>>8);
			buff[499] = ( byte) (a);
			buff[500] = ( byte) ( (a=inst.FSVA.value[1])>>8);
			buff[501] = ( byte) (a);
			buff[502] = ( byte) ( (a=inst.FSVA.value[2])>>8);
			buff[503] = ( byte) (a);
			buff[504] = ( byte) ( (a=inst.FSVA.value[3])>>8);
			buff[505] = ( byte) (a);
			buff[506] = ( byte) ( (a=inst.FSVA.value[4])>>8);
			buff[507] = ( byte) (a);
			buff[508] = ( byte) ( (a=inst.FSVA.value[5])>>8);
			buff[509] = ( byte) (a);
			buff[510] = ( byte) ( (a=inst.FSVA.value[6])>>8);
			buff[511] = ( byte) (a);
			buff[512] = ( byte) ( (a=inst.FSVA.value[7])>>8);
			buff[513] = ( byte) (a);
			buff[514] = ( byte) ( (a=inst.FSVA.value[8])>>8);
			buff[515] = ( byte) (a);
			buff[516] = ( byte) ( (a=inst.FSVA.value[9])>>8);
			buff[517] = ( byte) (a);
			buff[518] = ( byte) ( (a=inst.FSVA.value[10])>>8);
			buff[519] = ( byte) (a);
			buff[520] = ( byte) ( (a=inst.FSVA.value[11])>>8);
			buff[521] = ( byte) (a);
			buff[522] = ( byte) ( (a=inst.FSVA.value[12])>>8);
			buff[523] = ( byte) (a);
			buff[524] = ( byte) ( (a=inst.FSVA.value[13])>>8);
			buff[525] = ( byte) (a);
			buff[526] = ( byte) ( (a=inst.FSVA.value[14])>>8);
			buff[527] = ( byte) (a);

			inst.control[17]=1;
			for (int k = 498; k < 528; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[17]=3;
					break;
				}
			}
		}
		//inst.KTV1 {8, 15, 6}
		if(inst.control[18]==2){
				record[0].bufferPointer = 528;
				record[0].set( getKTV1(), 15, 6);
		}
		//inst.KTV2 {8, 15, 6}
		if(inst.control[19]==2){
				record[0].bufferPointer = 536;
				record[0].set( getKTV2(), 15, 6);
		}
		//inst.RTVN {8, 15, 6}
		if(inst.control[20]==2){
				record[0].bufferPointer = 544;
				record[0].set( getRTVN(), 15, 6);
		}
		//inst.LTVN {8, 15, 6}
		if(inst.control[21]==2){
				record[0].bufferPointer = 552;
				record[0].set( getLTVN(), 15, 6);
		}
		//inst.LRQT {8, 15, 6}
		if(inst.control[22]==2){
				record[0].bufferPointer = 560;
				record[0].set( getLRQT(), 15, 6);
		}
		//inst.DRQT {8, 15, 6}
		if(inst.control[23]==2){
				record[0].bufferPointer = 568;
				record[0].set( getDRQT(), 15, 6);
		}
		//inst.TTQT {8, 15, 6}
		if(inst.control[24]==2){
				record[0].bufferPointer = 576;
				record[0].set( getTTQT(), 15, 6);
		}
		//inst.DTVA {30, 15, 0}
		if(inst.control[25]==2){
			buff[584] = ( byte) ( (a=inst.DTVA.value[0])>>8);
			buff[585] = ( byte) (a);
			buff[586] = ( byte) ( (a=inst.DTVA.value[1])>>8);
			buff[587] = ( byte) (a);
			buff[588] = ( byte) ( (a=inst.DTVA.value[2])>>8);
			buff[589] = ( byte) (a);
			buff[590] = ( byte) ( (a=inst.DTVA.value[3])>>8);
			buff[591] = ( byte) (a);
			buff[592] = ( byte) ( (a=inst.DTVA.value[4])>>8);
			buff[593] = ( byte) (a);
			buff[594] = ( byte) ( (a=inst.DTVA.value[5])>>8);
			buff[595] = ( byte) (a);
			buff[596] = ( byte) ( (a=inst.DTVA.value[6])>>8);
			buff[597] = ( byte) (a);
			buff[598] = ( byte) ( (a=inst.DTVA.value[7])>>8);
			buff[599] = ( byte) (a);
			buff[600] = ( byte) ( (a=inst.DTVA.value[8])>>8);
			buff[601] = ( byte) (a);
			buff[602] = ( byte) ( (a=inst.DTVA.value[9])>>8);
			buff[603] = ( byte) (a);
			buff[604] = ( byte) ( (a=inst.DTVA.value[10])>>8);
			buff[605] = ( byte) (a);
			buff[606] = ( byte) ( (a=inst.DTVA.value[11])>>8);
			buff[607] = ( byte) (a);
			buff[608] = ( byte) ( (a=inst.DTVA.value[12])>>8);
			buff[609] = ( byte) (a);
			buff[610] = ( byte) ( (a=inst.DTVA.value[13])>>8);
			buff[611] = ( byte) (a);
			buff[612] = ( byte) ( (a=inst.DTVA.value[14])>>8);
			buff[613] = ( byte) (a);

			inst.control[25]=1;
			for (int k = 584; k < 614; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[25]=3;
					break;
				}
			}
		}
		//inst.DOVA {30, 15, 0}
		if(inst.control[26]==2){
			buff[614] = ( byte) ( (a=inst.DOVA.value[0])>>8);
			buff[615] = ( byte) (a);
			buff[616] = ( byte) ( (a=inst.DOVA.value[1])>>8);
			buff[617] = ( byte) (a);
			buff[618] = ( byte) ( (a=inst.DOVA.value[2])>>8);
			buff[619] = ( byte) (a);
			buff[620] = ( byte) ( (a=inst.DOVA.value[3])>>8);
			buff[621] = ( byte) (a);
			buff[622] = ( byte) ( (a=inst.DOVA.value[4])>>8);
			buff[623] = ( byte) (a);
			buff[624] = ( byte) ( (a=inst.DOVA.value[5])>>8);
			buff[625] = ( byte) (a);
			buff[626] = ( byte) ( (a=inst.DOVA.value[6])>>8);
			buff[627] = ( byte) (a);
			buff[628] = ( byte) ( (a=inst.DOVA.value[7])>>8);
			buff[629] = ( byte) (a);
			buff[630] = ( byte) ( (a=inst.DOVA.value[8])>>8);
			buff[631] = ( byte) (a);
			buff[632] = ( byte) ( (a=inst.DOVA.value[9])>>8);
			buff[633] = ( byte) (a);
			buff[634] = ( byte) ( (a=inst.DOVA.value[10])>>8);
			buff[635] = ( byte) (a);
			buff[636] = ( byte) ( (a=inst.DOVA.value[11])>>8);
			buff[637] = ( byte) (a);
			buff[638] = ( byte) ( (a=inst.DOVA.value[12])>>8);
			buff[639] = ( byte) (a);
			buff[640] = ( byte) ( (a=inst.DOVA.value[13])>>8);
			buff[641] = ( byte) (a);
			buff[642] = ( byte) ( (a=inst.DOVA.value[14])>>8);
			buff[643] = ( byte) (a);

			inst.control[26]=1;
			for (int k = 614; k < 644; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[26]=3;
					break;
				}
			}
		}
		//inst.UDF1 {30, 15, 0}
		if(inst.control[27]==2){
			buff[644] = ( byte) ( (a=inst.UDF1.value[0])>>8);
			buff[645] = ( byte) (a);
			buff[646] = ( byte) ( (a=inst.UDF1.value[1])>>8);
			buff[647] = ( byte) (a);
			buff[648] = ( byte) ( (a=inst.UDF1.value[2])>>8);
			buff[649] = ( byte) (a);
			buff[650] = ( byte) ( (a=inst.UDF1.value[3])>>8);
			buff[651] = ( byte) (a);
			buff[652] = ( byte) ( (a=inst.UDF1.value[4])>>8);
			buff[653] = ( byte) (a);
			buff[654] = ( byte) ( (a=inst.UDF1.value[5])>>8);
			buff[655] = ( byte) (a);
			buff[656] = ( byte) ( (a=inst.UDF1.value[6])>>8);
			buff[657] = ( byte) (a);
			buff[658] = ( byte) ( (a=inst.UDF1.value[7])>>8);
			buff[659] = ( byte) (a);
			buff[660] = ( byte) ( (a=inst.UDF1.value[8])>>8);
			buff[661] = ( byte) (a);
			buff[662] = ( byte) ( (a=inst.UDF1.value[9])>>8);
			buff[663] = ( byte) (a);
			buff[664] = ( byte) ( (a=inst.UDF1.value[10])>>8);
			buff[665] = ( byte) (a);
			buff[666] = ( byte) ( (a=inst.UDF1.value[11])>>8);
			buff[667] = ( byte) (a);
			buff[668] = ( byte) ( (a=inst.UDF1.value[12])>>8);
			buff[669] = ( byte) (a);
			buff[670] = ( byte) ( (a=inst.UDF1.value[13])>>8);
			buff[671] = ( byte) (a);
			buff[672] = ( byte) ( (a=inst.UDF1.value[14])>>8);
			buff[673] = ( byte) (a);

			inst.control[27]=1;
			for (int k = 644; k < 674; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[27]=3;
					break;
				}
			}
		}
		//inst.RGDT {5, 8, 0}
		if(inst.control[28]==2){
			if( inst.RGDT<0)
			{
				i = ( -inst.RGDT)%100000000;
				buff[678] = ( byte)( ( ( i%10)<<4) | 0xd);
			}
			else
			{
				i = inst.RGDT%100000000;
			buff[678] = ( byte)( ( ( i%10)<<4) | 0xf);
			}
			i/=10;
			buff[677] = ( byte)( ( i%10) | ( ( ( i/10)%10) << 4));
			i/=100;
			buff[676] = ( byte)( ( i%10) | ( ( ( i/10)%10) << 4));
			i/=100;
			buff[675] = ( byte)( ( i%10) | ( ( ( i/10)%10) << 4));
			i/=100;
			buff[674] = ( byte)( i);
		}
		//inst.RGTM {4, 6, 0}
		if(inst.control[29]==2){
			if( inst.RGTM<0)
			{
				i = ( -inst.RGTM)%1000000;
				buff[682] = ( byte)( ( ( i%10)<<4) | 0xd);
			}
			else
			{
				i = inst.RGTM%1000000;
			buff[682] = ( byte)( ( ( i%10)<<4) | 0xf);
			}
			i/=10;
			buff[681] = ( byte)( ( i%10) | ( ( ( i/10)%10) << 4));
			i/=100;
			buff[680] = ( byte)( ( i%10) | ( ( ( i/10)%10) << 4));
			i/=100;
			buff[679] = ( byte)( i);
		}
		//inst.LMDT {5, 8, 0}
		if(inst.control[30]==2){
			if( inst.LMDT<0)
			{
				i = ( -inst.LMDT)%100000000;
				buff[687] = ( byte)( ( ( i%10)<<4) | 0xd);
			}
			else
			{
				i = inst.LMDT%100000000;
			buff[687] = ( byte)( ( ( i%10)<<4) | 0xf);
			}
			i/=10;
			buff[686] = ( byte)( ( i%10) | ( ( ( i/10)%10) << 4));
			i/=100;
			buff[685] = ( byte)( ( i%10) | ( ( ( i/10)%10) << 4));
			i/=100;
			buff[684] = ( byte)( ( i%10) | ( ( ( i/10)%10) << 4));
			i/=100;
			buff[683] = ( byte)( i);
		}
		//inst.CHNO {2, 3, 0}
		if(inst.control[31]==2){
			if( inst.CHNO<0)
			{
				i = ( -inst.CHNO)%1000;
				buff[689] = ( byte)( ( ( i%10)<<4) | 0xd);
			}
			else
			{
				i = inst.CHNO%1000;
			buff[689] = ( byte)( ( ( i%10)<<4) | 0xf);
			}
			i/=10;
			buff[688] = ( byte)( ( i%10) | ( ( i/10) << 4));
		}
		//inst.CHID {20, 10, 0}
		if(inst.control[32]==2){
			buff[690] = ( byte) ( (a=inst.CHID.value[0])>>8);
			buff[691] = ( byte) (a);
			buff[692] = ( byte) ( (a=inst.CHID.value[1])>>8);
			buff[693] = ( byte) (a);
			buff[694] = ( byte) ( (a=inst.CHID.value[2])>>8);
			buff[695] = ( byte) (a);
			buff[696] = ( byte) ( (a=inst.CHID.value[3])>>8);
			buff[697] = ( byte) (a);
			buff[698] = ( byte) ( (a=inst.CHID.value[4])>>8);
			buff[699] = ( byte) (a);
			buff[700] = ( byte) ( (a=inst.CHID.value[5])>>8);
			buff[701] = ( byte) (a);
			buff[702] = ( byte) ( (a=inst.CHID.value[6])>>8);
			buff[703] = ( byte) (a);
			buff[704] = ( byte) ( (a=inst.CHID.value[7])>>8);
			buff[705] = ( byte) (a);
			buff[706] = ( byte) ( (a=inst.CHID.value[8])>>8);
			buff[707] = ( byte) (a);
			buff[708] = ( byte) ( (a=inst.CHID.value[9])>>8);
			buff[709] = ( byte) (a);

			inst.control[32]=1;
			for (int k = 690; k < 710; k++) {
				if (buff[k] != inst.loadedRec[k]) {
					inst.control[32]=3;
					break;
				}
			}
		}
		//inst.LMTS {10, 18, 0}
		if(inst.control[33]==2){
			if( inst.LMTS<0)
			{
				j = ( -inst.LMTS)%1000000000000000000L;
				buff[719] = ( byte)( ( ( j%10)<<4) | 0xd);
			}
			else
			{
				j = inst.LMTS%1000000000000000000L;
			buff[719] = ( byte)( ( ( j%10)<<4) | 0xf);
			}
			j/=10;
			buff[718] = ( byte)( ( j%10) | ( ( ( j/10)%10) << 4));
			j/=100;
			buff[717] = ( byte)( ( j%10) | ( ( ( j/10)%10) << 4));
			j/=100;
			buff[716] = ( byte)( ( j%10) | ( ( ( j/10)%10) << 4));
			j/=100;
			buff[715] = ( byte)( ( j%10) | ( ( ( j/10)%10) << 4));
			j/=100;
			buff[714] = ( byte)( ( j%10) | ( ( ( j/10)%10) << 4));
			j/=100;
			buff[713] = ( byte)( ( j%10) | ( ( ( j/10)%10) << 4));
			j/=100;
			buff[712] = ( byte)( ( j%10) | ( ( ( j/10)%10) << 4));
			j/=100;
			buff[711] = ( byte)( ( j%10) | ( ( ( j/10)%10) << 4));
			j/=100;
			buff[710] = ( byte)( j);
		}
		record[0].bufferPointer=719;

		System.arraycopy( buff, 0, inst.loadedRec, 0, 720);
		return record[0];
	}

	public byte[] getControl()
	{
		ensureInst();
		return inst.control;
	}

	public void setControl(byte[] con)
	{
		ensureInst();
		inst.control = con;
	}
	public static final byte[] clearedBuffer = {0x00,0x0F,
		0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x0F,
		0x00,0x00,0x00,0x00,0x0F,
		0x00,0x0F,
		0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,0x00,0x20,
		0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x0F,
		};
	public void setContents( MvxRecord mr, int LF)
	{
		
		ensureInst();
		System.arraycopy( mr.buffer, 0, inst.loadedRec, 0, 720);
		record[0] = mr;
		for(int c=0; c<34;c++){
			inst.control[c] = 0;
		}
	}

	//key methods
	public MvxRecord getKeyRec(String lf, int noOfFields) {
		return getKeyRec(getLFNumber(lf), noOfFields);
	}

	private MvxRecord key;

	public MvxRecord getKeyRec( int LFNo, int noOfFields) {
		ensureInst();
		if(inst.keyRecord[LFNo][noOfFields] == null){ 
			inst.keyRecord[LFNo][noOfFields] = new MvxRecord( mvx.db.def.dZDASHB.keySize[LFNo][noOfFields]);
		}
		key = inst.keyRecord[LFNo][noOfFields];
		switch( LFNo) {
			default:
			case 0:
				switch ( noOfFields) {
					default:
					case 0:
					case 3:
						if(inst.control[10]==0){
							System.arraycopy(record[0].buffer, 366, key.buffer, 22, 40);
						}else{
						key.bufferPointer = 22;
						key.set( getBANO());
						}
					case 2:
						if(inst.control[2]==0){
							System.arraycopy(record[0].buffer, 8, key.buffer, 2, 20);
						}else{
						key.bufferPointer = 2;
						key.set( getSUNO());
						}
					case 1:
						if(inst.control[0]==0){
							System.arraycopy(record[0].buffer, 0, key.buffer, 0, 2);
						}else{
						key.bufferPointer = 0;
						key.set( getCONO(), 3);
						}
					break;
				}
				return key;
			case 1:
				switch ( noOfFields) {
					default:
					case 0:
					case 3:
						if(inst.control[10]==0){
							System.arraycopy(record[0].buffer, 366, key.buffer, 22, 40);
						}else{
						key.bufferPointer = 22;
						key.set( getBANO());
						}
					case 2:
						if(inst.control[2]==0){
							System.arraycopy(record[0].buffer, 8, key.buffer, 2, 20);
						}else{
						key.bufferPointer = 2;
						key.set( getSUNO());
						}
					case 1:
						if(inst.control[0]==0){
							System.arraycopy(record[0].buffer, 0, key.buffer, 0, 2);
						}else{
						key.bufferPointer = 0;
						key.set( getCONO(), 3);
						}
					break;
				}
				return key;
		}
	}

	public static String comment = ";;";
	public static String version = "MAK_XJVAIDYA_12.4.2_240704_07:40";
}// END CLASS