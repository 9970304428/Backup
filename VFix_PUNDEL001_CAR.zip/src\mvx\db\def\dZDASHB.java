/*
DB-generator version: 12.4.2
*/
package mvx.db.def;

import mvx.db.common.GenericDef;
import mvx.runtime.MvxPool;

public class dZDASHB extends GenericDef {

	public static String[][] names = {
		{"ZDCONO","ZDDIVI","ZDSUNO","ZDSUNM","ZDROUT","ZDTX40","ZDWHLO","ZDWHNM","ZDTRCA","ZDTX402","ZDBANO","ZDATVA","ZDATVN","ZDTRQT","ZDKTVN","ZDKETN","ZDFTVA","ZDFSVA","ZDKTV1","ZDKTV2","ZDRTVN","ZDLTVN","ZDLRQT","ZDDRQT","ZDTTQT","ZDDTVA","ZDDOVA","ZDUDF1","ZDRGDT","ZDRGTM","ZDLMDT","ZDCHNO","ZDCHID","ZDLMTS"}
	};

	public static String[][] fieldHeadings = {
		{"WCO01","WDI01","WSU01","WSU03","WRO13","WDE02","WWH01","WDE02","WTR50","WDE02","WBA04","WAT83","WAT83","WTR01","WAT83","WAT83","WAT83","WAT83","WAT83","WAT83","WAT83","WAT83","WTR01","WTR01","WTR01","WAT83","WAT83",null,"WRGD1","WRG01","WLMD1","WCH03","WCH05","WLM10"}
	};

	public final static String fileType = "MF"; // Master File
	//file description
	public final static String fileDescription = "MF:Dashboard";
	private static boolean[] hasSelectOmit = null;

	private static int[] recordSize = { 720};

	private static int[] recordSizeEBCDIC = { 418};

	//Logic files
	final static String[] LFs = {"RR","00"};

	//Unique Logic files
	final static boolean[] uniqueLF = {false,true,};
	public boolean isLFUnique(int lfn)
	{
		return uniqueLF[lfn];
	}

	//mapper for LFs
	public int[] pos = { 0, 0};


	public static MvxPool dbPool = new MvxPool("ZDASHB", LFs);

	public dZDASHB()
	{

		init(fileDescription, fileType, fields, names, fieldHeadings, keys, recordSize, recordSizeEBCDIC, pos, LFs, hasSelectOmit, dbPool, false, false);
	}

	public final static int[][] keys = {
		{( DB_TYPE_ASC | (0 << 16) | 0)  	//RR - ZDCONO
		,( DB_TYPE_ASC | (2 << 16) | 2)  	//RR - ZDSUNO
		,( DB_TYPE_ASC | (10 << 16) | 22)  	//RR - ZDBANO

		},
		{( DB_TYPE_ASC | (0 << 16) | 0)  	//00 - ZDCONO
		,( DB_TYPE_ASC | (2 << 16) | 2)  	//00 - ZDSUNO
		,( DB_TYPE_ASC | (10 << 16) | 22)  	//00 - ZDBANO

		}
	};




	public static int[][] keySize = {
		{62, 2, 22, 62} ,
		{62, 2, 22, 62}
	};

	public final static long[][] fields = {
	{
		( ( 0	<< 16) | 3	| DB_TYPE_DEC ), 	//0 ZDCONO
		( ( 2	<< 16) | 3	| DB_TYPE_CHAR), 	//1 ZDDIVI
		( ( 8	<< 16) | 10	| DB_TYPE_CHAR), 	//2 ZDSUNO
		( ( 28	<< 16) | 36	| DB_TYPE_CHAR), 	//3 ZDSUNM
		( ( 100	<< 16) | 6	| DB_TYPE_CHAR), 	//4 ZDROUT
		( ( 112	<< 16) | 40	| DB_TYPE_CHAR), 	//5 ZDTX40
		( ( 192	<< 16) | 3	| DB_TYPE_CHAR), 	//6 ZDWHLO
		( ( 198	<< 16) | 36	| DB_TYPE_CHAR), 	//7 ZDWHNM
		( ( 270	<< 16) | 8	| DB_TYPE_CHAR), 	//8 ZDTRCA
		( ( 286	<< 16) | 40	| DB_TYPE_CHAR), 	//9 ZDTX402
		( ( 366	<< 16) | 20	| DB_TYPE_CHAR), 	//10 ZDBANO
		( ( 406	<< 16) | 15	| DB_TYPE_CHAR), 	//11 ZDATVA
		( ( 436	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//12 ZDATVN
		( ( 444	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//13 ZDTRQT
		( ( 452	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//14 ZDKTVN
		( ( 460	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//15 ZDKETN
		( ( 468	<< 16) | 15	| DB_TYPE_CHAR), 	//16 ZDFTVA
		( ( 498	<< 16) | 15	| DB_TYPE_CHAR), 	//17 ZDFSVA
		( ( 528	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//18 ZDKTV1
		( ( 536	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//19 ZDKTV2
		( ( 544	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//20 ZDRTVN
		( ( 552	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//21 ZDLTVN
		( ( 560	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//22 ZDLRQT
		( ( 568	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//23 ZDDRQT
		( ( 576	<< 16) | 15	| (6L << 32) | DB_TYPE_DEC ), 	//24 ZDTTQT
		( ( 584	<< 16) | 15	| DB_TYPE_CHAR), 	//25 ZDDTVA
		( ( 614	<< 16) | 15	| DB_TYPE_CHAR), 	//26 ZDDOVA
		( ( 644	<< 16) | 15	| DB_TYPE_CHAR), 	//27 ZDUDF1
		( ( 674	<< 16) | 8	| DB_TYPE_DEC ), 	//28 ZDRGDT
		( ( 679	<< 16) | 6	| DB_TYPE_DEC ), 	//29 ZDRGTM
		( ( 683	<< 16) | 8	| DB_TYPE_DEC ), 	//30 ZDLMDT
		( ( 688	<< 16) | 3	| DB_TYPE_DEC ), 	//31 ZDCHNO
		( ( 690	<< 16) | 10	| DB_TYPE_CHAR), 	//32 ZDCHID
		( ( 710	<< 16) | 18	| DB_TYPE_DEC ),	//33 ZDLMTS
	}};

	public String getNonKeyField() {
		return "ZDDIVI";
	}

	public int getNonKeyFieldIndex() {
		return 1;
	}
	public static char[][] fieldEditCode = { {'4',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ','M','M','M','M',' ',' ','M','M','M','M','M','M','M',' ',' ',' ','Z','4','Z','4',' ','M'},
				};
	public char getEditCode(int lfn, int field){
		return fieldEditCode[pos[lfn]][field];
	}
	public char getEditCode(int field){
		return fieldEditCode[0][field];
	}


	public String getTableSpace()
	{
		return "TMVXT";
	}
	public int getTablePctFree()
	{
		return 0;
	}

	public int getIndexPctFree()
	{
		return 0;
	}

	public String getDefaultSchema()
	{
		return "DTA";
	}


	public int getNrOfBlobs(int lfn)
	{
		switch(pos[lfn]){
		case 0:
			return 0;
		}
		return -1;
	}

	/**
	* Main program for CRUD on table
	* @return Name on the function programs that is used to maintain data in a specific table, e.g. MMS001
	*/
	public String getMaintainedByPgm(){
		return "MMS001";
	}
	/**
	* Archiving function
	* @return Name on the function programs that is used to archive data in a specific table, e.g. MWS810
	*/
	public String getArchivingFunction(){
		return "MWS810";
	}
	/**
	* Mass delete function
	* @return Name on the function programs that is used to delete all data in a specific table, e.g. MWS810
	*/
	public String getMassDeleteFunction(){
		return "MWS810";
	}
	/**
	* Message id for table description
	* @return Program heading ID, e.g. XMI1001
	*/
	public String getProgramHeading(){
		return "XMI1001";
	}

	public static String comment = ";;";
	public static String version = "MAK_XJVAIDYA_12.4.2_240704_07:40";
}
