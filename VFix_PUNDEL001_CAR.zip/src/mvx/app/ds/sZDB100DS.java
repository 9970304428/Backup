package mvx.app.ds;

import mvx.util.*;
import mvx.runtime.*;
import mvx.app.common.*;

public class sZDB100DS extends GenericDS{

    /*
    Pos  Variable             Length Offset Type
    ---------------------------------------------------
    0 ZFCONO                 3      0    int
    1 ZTCONO                 3      3    int
    2 ZZRQDT                 8      6    int
    ---------------------------------------------------
    Total lenght of ZDB100DS    14 
    */

    public static final String NAME="ZDB100DS";
    
    public sZDB100DS(MvxCoreFunc mcf){
        super(mcf);
    }

    public final MvxString setZDB100DS(){
        dsDirty = false;
        varsDirty = true;
        return ZDB100DS;
    }

    public final MvxString set(){
        return setZDB100DS();
    }

    public final MvxString getZDB100DS(){
        syncToDS();
        return ZDB100DS;
    }

    public final MvxString get(){
        return getZDB100DS();
    }

    public final int getZFCONO(){
        syncToVars();
        return ZFCONO;
    }

    public final void setZFCONO(int i){
        syncToVars();
        dsDirty = true;
        ZFCONO = i;
    }
    public final int getZTCONO(){
        syncToVars();
        return ZTCONO;
    }

    public final void setZTCONO(int i){
        syncToVars();
        dsDirty = true;
        ZTCONO = i;
    }
    public final int getZZRQDT(){
        syncToVars();
        return ZZRQDT;
    }

    public final void setZZRQDT(int i){
        syncToVars();
        dsDirty = true;
        ZZRQDT = i;
    }

    protected final void syncToVars(){
        if(varsDirty){
            ZFCONO = ZDB100DS.getInt(3,0);
            ZTCONO = ZDB100DS.getInt(3,3);
            ZZRQDT = ZDB100DS.getInt(8,6);
            varsDirty = false;
        }
    }

    protected final void syncToDS(){
        if(dsDirty){
            ZDB100DS.setIntAt(ZFCONO,0,3);
            ZDB100DS.setIntAt(ZTCONO,3,3);
            ZDB100DS.setIntAt(ZZRQDT,6,8);
            dsDirty = false;
        }
    }

    private MvxString ZDB100DS = new MvxString(14);
    private int ZFCONO = 0;
    private int ZTCONO = 0;
    private int ZZRQDT = 0;

    public void clear(){
        super.clear();
        ZDB100DS.clear();
        ZFCONO = 0;
        ZTCONO = 0;
        ZZRQDT = 0;
    }

    public final String getVersion(){
        return version;
    }

  public static final String version = "MAK_XJVAIDYA_240712_06:18"; /*$Revision: /main/DEV_12/SP_12.4.6/6 $*/
}
