package mvx.app.pgm.customer;

import mvx.app.common.*;
import mvx.app.plist.*;
import mvx.app.ds.*;
import mvx.util.*;

import mvx.dsp.obj.*;
import mvx.dsp.common.GenericDSP;
/*
*Modification area - M3
*Nbr            Date   User id     Description
*99999999999999 999999 XXXXXXXXXX  x
*Modification area - Business partner
*Nbr            Date   User id     Description
*99999999999999 999999 XXXXXXXXXX  x
*Modification area - Customer
*Nbr            Date   User id     Description
*      HUKI-263 190705 VAIDJZ      Hybris, cancelled carts also to be cancelled in M3 Hybris ticket ESAB-EU233
*     PUNDEL001 240712 XJVAIDYA    Primary Production Dashboard development
*/

/**
 * <BR>
 * <B><FONT SIZE=+2>Lst: Hybris Basket Management</FONT></B><BR>
 * <BR>
 *
 *
 */

public class ZDB100 extends Interactive {
	
	/**
	 * PEDSP - Display
	 */
	public void PEDSP_F03() {
		super.PEDSP_F03();
	}

	public void PEINZ() {
		// Next step
		picSetMethod('D');
		// Start parameters
		SYSTP.setCONO(LDAZD.CONO);
		SYSTP.setDIVI().moveLeft(LDAZD.DIVI);
		SYSTP.setPGNM().move(this.DSPGM);
		SYSTP.setRESP().move(LDAZD.RESP);
		IN91 = !SYSTP.CHAIN("00", SYSTP.getKey("00", 4));
		if (IN91) {
			SYSTP.clearNOKEY("00");
			ZDB100DS.setZDB100DS().clear();
			moveToIN(41, "10");
		} else {
			if (!IN49) {
				ZDB100DS.setZDB100DS().moveLeft(SYSTP.getPARA());
			}
		}
		
}

	/* PEDSP */
	public String PEDSP_getReadNames() {
		return "E0";
	}

	public String PEDSP_getWriteNames() {
		return "E0";
	}

	public void PECHK() {
		// Next step
		picSetMethod('U');

		clear(PXQRYSLT.PXKY);
		PXQRYSLT.PXTYP.move("L ");
		IN92 = PXQRYSLT.CQRYSLT();
	}

	public void PEUPD() {
		IN91 = !SYSTP.CHAIN_LOCK("10", SYSTP.getKey("10", 4));
		IN92 = SYSTP.getErr("10");
		if (!IN49 && !IN91) {
			ZDB100DS.setZDB100DS().moveLeft(SYSTP.getPARA());
		}
		PEUPDX: do {
			// Update of deleted record
			if (IN42 && IN91) {
				picSetMethod('D');
				DSP.setFocus(4, 18, "ZEFACI");
				IN60 = true;
				// MSGID=XDE0001 The record has been deleted by another user
				this.MSGID.move("XDE0001");
				COMPMQ();
				break PEUPDX;
			}
			// Update of changed record
			if (IN42 && (!IN91) && (this.XXCHNO != (SYSTP.getCHNO()))) {
				SYSTP.UNLOCK("10");
				picSetMethod('D');
				IN60 = true;
				DSP.setFocus(4, 18, "ZEFACI");
				// MSGID=XUP0001 The record has been changed by user &1
				COMPMQ("XUP0001", formatToString(SYSTP.getCHID()));
				break PEUPDX;
			}
			// Add to an existing record
			if (IN41 && (!IN91)) {
				SYSTP.UNLOCK("10");
				picSetMethod('D');
				IN60 = true;
				DSP.setFocus(4, 18, "ZEFACI");
				// MSGID=XAD0001 A record has been entered by user &1
				COMPMQ("XAD001", formatToString(SYSTP.getCHID()));
				break PEUPDX;
			}
			break;
		} while (true);
		ZDB100DS.setZZRQDT(DSP.ZERQDT);
		
		this.XXCHNO = SYSTP.getCHNO();
		if (!IN49) {
			SYSTP.setPARA().moveLeftPad(ZDB100DS.getZDB100DS());
		}
		this.PXDFMI.moveLeftPad("TIME");
		this.PXDATI = 0;
		this.PXDFMO.moveLeftPad("YMD8");
		this.PXOPRM = 1;
		COMDAT();
		SYSTP.setLMDT(this.PXDATO);
		SYSTP.setCHID().move(this.DSUSS);
		SYSTP.setCHNO(SYSTP.getCHNO() + 1);
		this.XXCHNO = SYSTP.getCHNO();
		if (!IN91) {
			SYSTP.UPDAT("10");
		} else {
			SYSTP.setRGDT(SYSTP.getLMDT());
			SYSTP.setRGTM(movexTime());
			SYSTP.WRITE("10");
		}
		// Next step
		picSetMethod('D');
		picPush('O', 'I');
	}


	public void POMAIN() {
		// Batch jobnumber (CMBJNO)
		JBCMD.setBJNO().moveLeftPad(this.getBJNO());
		do {
			IN91 = JBCMD.DELET("00", JBCMD.getKey("00", 1));
		} while (!(IN91));
		// Common data
		JBCMD.clearNOKEY("00");
		JBCMD.setCONO(LDAZD.CONO);
		JBCMD.setJNA().move(this.DSJNA);
		JBCMD.setJNU(this.DSJNU.getInt());
		JBCMD.setLMDT(SYSTP.getLMDT());
		JBCMD.setCHID().move(this.DSUSS);
		JBCMD.setCHNO(1);
		JBCMD.setRGDT(JBCMD.getLMDT());
		JBCMD.setRGTM(movexTime());
		
			// Select job data
		DSP.clearSFL("O0");
		this.PXCONO = LDAZD.CONO;
		PXMNS230.PXJOB.moveLeft("ZDB101");
		PXCHKPRL.PXUSID.move(this.DSUSS);
		PXCHKPRL.PXDEVD.move(this.DSJNA);
		// MSGID=MM65701 not found anywhere
		PXMNS210.PXMSID.move("");
		PXMNS230.PXBJNO.move(JBCMD.getBJNO());
		PXMNS230.PXPGM.moveLeft("ZDB101CL");
		PXQRYSLT.DSQCMD.clear();
		PXMNS230SyncTo();
		PXMNS230.DSJBDA.clear();
		PXMNS230SyncFrom();
		PXMNS230SyncTo();
		IN92 = PXMNS230.MNS230();
		PXMNS230SyncFrom();
		// F03=End
		if (F03 == LDAZZ.FKEY) {
			do {
				IN91 = JBCMD.DELET("00", JBCMD.getKey("00", 1));
			} while (!(IN91));
			picFinish();
			return;
		}
		// F12=Previous
		if (F12 == LDAZZ.FKEY) {
			do {
				IN91 = JBCMD.DELET("00", JBCMD.getKey("00", 1));
			} while (!(IN91));
			picPop();
			return;
		}
		// Line 90 - Save job data
		JBCMD.setBJLI().move("90");
		JBCMD.setBJLT().move("JOB");
		JBCMD.setFILE().move(PXMNS230.PXPGM);
		JBCMD.setQCMD().move(PXQRYSLT.DSQCMD);
		JBCMD.setDATA().move(PXMNS230.DSJBDA);
		JBCMD.WRITE("00");
		 //Line 95 - Save key data
		 JBCMD.setBJLI().move("95");
		 JBCMD.setBJLT().move("KEY");
		 JBCMD.setFILE().clear();
		 JBCMD.setQCMD().clear();
		 JBCMD.setQCMD().moveFromArray(PXQRYSLT.PXKY);
		 JBCMD.setDATA().clear();
		 JBCMD.WRITE("00");
		
		JBCMD.setBJLI().move("99");
		JBCMD.setBJLT().move("SLT");
		JBCMD.setFILE().clear();
		JBCMD.setQCMD().moveLeftPad(ZDB100DS.getZDB100DS());
		JBCMD.setDATA().clear();
		JBCMD.WRITE("00");
		// Execute job
		if (LDAZZ.DBGM == 1) {
			pZDB101CLpreCall();
			apCall("ZDB101CL", pZDB101CL);
			pZDB101CLpostCall();
		} else {
			rQCMDpreCall();
			apCall("QCMDEXC", rQCMD);
			rQCMDpostCall();
		}

		// Next step

		picPop();

	}

	public void SAVSTR() {
		// Update start values

		IN91 = !SYSTR.CHAIN_LOCK("00", KSYSTR());
		IN92 = SYSTR.getErr("00");
		if (!IN91) {
			this.PXDFMI.moveLeftPad("TIME");
			this.PXDATI = 0;
			this.PXDFMO.moveLeftPad("YMD8");
			this.PXOPRM = 1;
			COMDAT();
			SYSTR.setLMDT(this.PXDATO);
			CSIN52.move(toChar(IN52));
			CSIN53.move(toChar(IN53));
			CSIN54.move(toChar(IN54));
			// MOVE WWOPT2 CSOPT2
			SYSTR.setPAR1().moveLeft(XXPAR1);
			SYSTR.UPDAT("00");

		}

	}

	public void SETLR() {
		super.SETLR();
		// Last function key
		// LDAZD.FKEY.move(DSP.X0FKEY);
		INLR = true;

	}

	public void INIT() {
		SYSTP.setDIVI().clear();
		SYSTR.setDIVI().clear();
		SYSTP.setCONO(LDAZD.CONO);
		SYSTP.setRGDT(0);
		this.PXCONO = LDAZD.CONO;
		this.PXDIVI.clear();
		this.PXPGNM.move(this.DSPGM);
		this.PXAUPF.moveRight(LDAZD.AUPF);
		this.PXDFMI.move("TIME");
		this.PXDATI = 0;
		this.PXDFMO.move("YMD8");
		this.PXOPRM = 1;
		COMDAT();
		this.CUDATE = this.PXDATO;
		// Check authority
		PXAUTCHK.CAUTCHK();
		this.PXO.move(this.PXALOP);
		// Not allowed to run program
		if (this.PXALPG == 0) {
			// MSGID=XAU0002 You are not authorized to run the program &1
			SRCOMRCM.MSGLVL.moveLeft("*PRV");
			COMPMQ("XAU0002", formatToString(this.DSPGM));
			SETLR();
			return;
		}

		// Field authority
		moveToIN(1, LDAZD.AUFI);
		// Clear display
		// Check start values
		IN91 = !SYSTR.CHAIN("00", SYSTR.getKey("00"));
		IN92 = SYSTR.getErr("00");
		if (IN91) {
			SAVSTR_BeforeUpdate();
			SYSTR.clear();
			SYSTR.setPAR1().move(XXPAR1);
			SYSTR.setCONO(LDAZD.CONO);
			SYSTR.setPGNM().move(this.DSPGM);
			SYSTR.setRESP().move(LDAZD.RESP);
			SYSTR.setRGDT(this.CUDATE);
			SYSTR.setLMDT(SYSTR.getRGDT());
			SYSTR.WRITE("00");
		}
		PEUPD_BeforeUpdate();
		XXPAR1.move(SYSTR.getPAR1());
		// XXPAR2.move(SYSTR.getPAR2());
		// rXXPAR2SyncFrom();
		IN52 = toBoolean(CSIN52.getChar());
		IN53 = toBoolean(CSIN53.getChar());
		IN54 = toBoolean(CSIN54.getChar());
		// Check start picture
		if (!LDAZZ.FPNM.isBlank() && !LDAZZ.PICC.isBlank()) {
			picSet("E");
			//DSP.ZEFACI.move(LDAZZ.FACI);

		} else {
			picSetMethod('I');
		}
		SYSTR.setRGDT(0);
	

		// Clear data structure
		ZDB100DS.setZDB100DS().clear();
		// Common object GUIUSR - Prepare for GUI-user

	}

	public void PXMNS230SyncTo() {
		PXMNS230.PXUSID.move(PXCHKPRL.PXUSID);
		PXMNS230.DSQCMD.move(PXQRYSLT.DSQCMD);
		PXMNS230.PXDEVD.move(PXCHKPRL.PXDEVD);
		PXMNS230.PXMSID.move(PXMNS210.PXMSID);
	}

	public void PXMNS230SyncFrom() {
		PXCHKPRL.PXUSID.move(PXMNS230.PXUSID);
		PXQRYSLT.DSQCMD.move(PXMNS230.DSQCMD);
		PXCHKPRL.PXDEVD.move(PXMNS230.PXDEVD);
		PXMNS210.PXMSID.move(PXMNS230.PXMSID);
	}

	
	public void PERROR() {
		picSet("EI");

	}

	public ZDB100DSP DSP;

	public void initDSP() {
		if (DSP == null) {
			DSP = new ZDB100DSP(this);
		}
	}

	public GenericDSP getDSP() {
		return (GenericDSP) DSP;
	}

	// *PARAM rZDB100CL{
	public MvxRecord rZDB100CL = new MvxRecord();

	public void rZDB100CLpreCall() {// insert param into record for call
		rZDB100CL.reset();
		rZDB100CL.set(JBCMD.getBJNO());
	}

	public void rZDB100CLpostCall() {// insert param into record for call
		rZDB100CL.reset();
		rZDB100CL.getString(JBCMD.getBJNO());
	}
	// public cPXMNS215 PXMNS215 = new cPXMNS215(this);

	public void PXMNS210SyncTo() {
		PXMNS210.PXUSID.move(PXCHKPRL.PXUSID);
		PXMNS210.CMBJNO.move(JBCMD.getBJNO());
		PXMNS210.DSQCMD.move(PXQRYSLT.DSQCMD);
		PXMNS210.PXDEVD.move(PXCHKPRL.PXDEVD);
		PXMNS210.PXPRTF.move(PXCHKPRL.PXPRTF);
	}

	public void PXMNS210SyncFrom() {
		PXCHKPRL.PXUSID.move(PXMNS210.PXUSID);
		JBCMD.setBJNO().move(PXMNS210.CMBJNO);
		PXQRYSLT.DSQCMD.move(PXMNS210.DSQCMD);
		PXCHKPRL.PXDEVD.move(PXMNS210.PXDEVD);
		PXCHKPRL.PXPRTF.move(PXMNS210.PXPRTF);
	}

	// public cPXMNS210 PXMNS210 = new cPXMNS210(this);

	public void PXQRYKEYSyncTo() {
		moveArray(PXQRYKEY.PXKY, PXQRYSLT.PXKY);
		PXQRYKEY.DSQCMD.move(PXQRYSLT.DSQCMD);
	}

	public void PXQRYKEYSyncFrom() {
		moveArray(PXQRYSLT.PXKY, PXQRYKEY.PXKY);
		PXQRYSLT.DSQCMD.move(PXQRYKEY.DSQCMD);
	}

	// public cPXQRYKEY PXQRYKEY = new cPXQRYKEY(this);
	// *PARAM rCRTVBJN{
	public MvxRecord rCRTVBJN = new MvxRecord();

	public void rCRTVBJNpreCall() {// insert param into record for call
		rCRTVBJN.reset();
		rCRTVBJN.set(JBCMD.getBJNO());
	}

	public void rCRTVBJNpostCall() {// insert param into record for call
		rCRTVBJN.reset();
		rCRTVBJN.getString(JBCMD.getBJNO());
	}

	// *PARAM rQCMD{
	public MvxRecord rQCMD = new MvxRecord();// len = 2015

	public void rQCMDpreCall() {// insert param into record for call
		rQCMD.reset();
		rQCMD.set(PXQRYSLT.DSQCMD);
		rQCMD.set(2000d, 15, 5);
	}

	public double PXLEN;// *LIKE XXN155

	public void rQCMDpostCall() {// extract param from record after call
		rQCMD.reset();
		rQCMD.getString(PXQRYSLT.DSQCMD);
		PXLEN = rQCMD.getDouble(15, 5);
	}

	public MvxRecord pZDB101CL = new MvxRecord();// len = 18

	public void pZDB101CLpreCall() {// insert param into record for call
		pZDB101CL.reset();
		pZDB101CL.set(JBCMD.getBJNO());
	}

	public void pZDB101CLpostCall() {// extract param from record after call

		pZDB101CL.reset();
		pZDB101CL.getString(JBCMD.setBJNO());
	}

	
	public MvxStruct rXXPAR1 = new MvxStruct(100);
	public MvxString XXPAR1 = rXXPAR1.newString(0, 100);
	public MvxString CSSPIC = rXXPAR1.newChar(0);
	public MvxString rXXPAR1_CSSQ = rXXPAR1.newString(1, 10);
	public MvxString CSIN52 = rXXPAR1.newChar(11);
	public MvxString CSIN53 = rXXPAR1.newChar(12);
	public MvxString CSIN54 = rXXPAR1.newChar(13);
	public MvxString CSCFEN = rXXPAR1.newChar(14);
	public MvxString CSORTP = rXXPAR1.newString(15, 3);
	public MvxString CSOTCD = rXXPAR1.newChar(18);
	public MvxString CSSQCD = rXXPAR1.newChar(19);
	public MvxString CSDTFM = rXXPAR1.newString(20, 3);
	public MvxString CSASEQ = rXXPAR1.newString(23, 10);
	public MvxString CSADR2 = rXXPAR1.newChar(33);
	public MvxString CSKRLD = rXXPAR1.newChar(34);
	public MvxString CSCAPM = rXXPAR1.newChar(35);

	
	public int XXCHNO; // TODO Check field size
	public MvxString XFPGNM = new MvxString(10); // TODO Check field size//
													// Write Local Variables
	public MvxString XXSPGB = new MvxString(3);
	public int XP;
	public MvxString XXN70 = new MvxString(7);
	public MvxString Z0PICC = new MvxString(2);
	public MvxString XLPIC1 = new MvxString(1);
//	public MvxString SQ = new MvxString(3);
	//public MvxString XI = new MvxString(3);

	// Extenal Data Structures
	public sZDB100DS ZDB100DS = new sZDB100DS(this);
	public mvx.db.dta.CSYSTP SYSTP;
	mvx.db.dta.CJBCMD JBCMD;
	public mvx.db.dta.MITFAC ITFAC;

	public void initMDB() {
		SYSTP = (mvx.db.dta.CSYSTP) getMDB("CSYSTP", SYSTP);
		SYSTP.setAccessProfile("10", 'U');
		//SYCAL.setAccessProfile("00", 'R');
		SYSTR.setAccessProfile("00", 'U');
		JBCMD = (mvx.db.dta.CJBCMD) getMDB("CJBCMD", JBCMD);
		JBCMD.setAccessProfile("00", 'U');
		//STKBL = (mvx.db.dta.ZSTKBL) getMDB("ZSTKBL", STKBL);
		//STKBL.setAccessProfile("00", 'R');
		ITFAC = (mvx.db.dta.MITFAC) getMDB("MITFAC", ITFAC);
		ITFAC.setAccessProfile("00", 'R');
	}

	// public MvxString[] PIC = newMvxStrings(100,2);
	// public MvxString PXO = new MvxString(9);
	// public MvxString LIN = new MvxString(11);
	// public MvxString[] PXAL = newMvxStrings(9,50);
	// public int[] PXNU = new int[9];
	// public MvxString[] PXKY = newMvxStrings(15,30);
	// public MvxString[] PXFI = newMvxStrings(9,10);
	// public MvxString[] PXJF = newMvxStrings(9,15);
	// public MvxString[] PXJT = newMvxStrings(9,15);
	// public MvxString[] PXJO = newMvxStrings(9,3);
	public MvxRecord KSYSTR() {
		keyKSYSTR.reset();
		keyKSYSTR.set(LDAZD.CONO, 3);// *LIKE CONO
		keyKSYSTR.set(SYSTR.getDIVI());// *LIKE DIVI
		keyKSYSTR.set(this.DSPGM);// *LIKE PGM
		keyKSYSTR.set(LDAZD.RESP);// *LIKE RESP
		return keyKSYSTR;
	}

	public MvxRecord keyKSYSTR = new MvxRecord(48);

	// public cSRCOMRCM SRCOMRCM= new cSRCOMRCM(this);
	// public cPXAUTCHK PXAUTCHK= new cPXAUTCHK(this);
	// public cPLCHKAF PLCHKAF= new cPLCHKAF(this);
	public cPXCHKPRL PXCHKPRL = new cPXCHKPRL(this);
	public cPXQRYSLT PXQRYSLT = new cPXQRYSLT(this);
	public cPXQRYKEY PXQRYKEY = new cPXQRYKEY(this);
	// public cPXQRYOPN PXQRYOPN= new cPXQRYOPN(this);
	public cPXMNS210 PXMNS210 = new cPXMNS210(this);
	public cPXMNS215 PXMNS215 = new cPXMNS215(this);
	public cPXMNS230 PXMNS230 = new cPXMNS230(this);

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public String getVarList(java.util.Vector v) {
		super.getVarList(v);
		v.addElement(SYSTP);
		v.addElement(SYSTR);
		v.addElement(JBCMD);
		v.addElement(ITFAC);	
		v.addElement(ZDB100DS);
		v.addElement(XXCHNO);
		v.addElement(XFPGNM);
		v.addElement(rQCMD);
		v.addElement(DSP);
		v.addElement(rCRTVBJN);
		v.addElement(pZDB101CL);
	    v.addElement(Z0PICC);
		v.addElement(XLPIC1);
		v.addElement(PXAUTCHK);
		// v.addElement(PLCHKAF);
		v.addElement(PXCHKPRL);
		v.addElement(PXQRYSLT);
		v.addElement(PXQRYKEY);
	
		v.addElement(PXMNS210);
		v.addElement(PXMNS215);
		v.addElement(PXMNS230);
		return version;
	}

	public void clearInstance() {
		super.clearInstance();
		PXLEN = 0D;
		XP = 0;
		// XXCOPY = false;
	}

	public String getVer() {
		return version;
	}

	public final String version = "Pgm.Name: ZMM520, " + "Source creation date: Thu JUL 31 16:41:25 CEST 2018, "
			+ "ID number: 991320085718";

	public String getVersion() {
		return _version;
	} // �end of method getVersion

	public String getRelease() {
		return _release;
	} // �end of method getRelease

	public String getSpLevel() {
		return _spLevel;
	} // �end of method getSpLevel

	public String getSpNumber() {
		return _spNumber;
	} // �end of method getSpNumber

	public final static String _version = "15";
	public final static String _release = "1";
	public final static String _spLevel = "4";
	public final static String _spNumber ="MAK_XJVAIDYA_240712_06:42";
	public final static String _GUID = "2F44D783CA244e34A875474B8AAF8AD8";
	public final static String _tempFixComment = "";
	public final static String _build = "000000000000080";
	public final static String _pgmName = "ZMM520";

	public String getGUID() {
		return _GUID;
	} // �end of method getGUID

	public String getTempFixComment() {
		return _tempFixComment;
	} // �end of method getTempFixComment

	public String getVersionInformation() {
		return _version + '.' + _release + '.' + _spLevel + ':' + _spNumber;
	} // �end of method getVersionInformation

	public String getBuild() {
		return (_version + _release + _build + "      " + _pgmName + "                                   ").substring(0,
				34);
	} // �end of method getBuild

	public String[][] getCustomerModifications() {
		return _getCustomerModifications;
	} // end of method [][] getStandardModification()

	public final static String[][] _getCustomerModifications = {};

   public String [][] getCustomerModification() {
      return _customerModifications;
   } // end of method [][] getCustomerModification()

   public final static String [][] _customerModifications={
      {"HUKI-263","190705","VAIDJZ","Hybris, cancelled carts also to be cancelled in M3 Hybris ticket ESAB-EU233"},
      {"PUNDEL001","240712","XJVAIDYA","Primary Production Dashboard development"}
   };
}