/*
 ***************************************************************
 *                                                             *
 *                           NOTICE                            *
 *                                                             *
 *   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
 *   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
 *   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
 *   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
 *   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
 *   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
 *   ALL OTHER RIGHTS RESERVED.                                *
 *                                                             *
 *   (c) COPYRIGHT 2016 INFOR.  ALL RIGHTS RESERVED.           *
 *   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
 *   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
 *   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
 *   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
 *   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
 *                                                             *
 ***************************************************************
 */
package mvx.app.pgm.customer;
import mvx.app.common.*;
import mvx.app.ds.*;
import mvx.util.*;
//import mvx.db.common.Expression;
//import mvx.db.common.FieldSelection;

/*
 *Modification area - M3
 *Nbr            Date   User id     Description
 *    
 *Modification area - Business partner
 *Nbr            Date   User id     Description
 *99999999999999 999999 XXXXXXXXXX  x
 *Modification area - Customer
 *Nbr            Date   User id     Description
 *      HUKI-263 190626 VAIDJZ      Hybris, cancelled carts also to be cancelled in M3 Hybris ticket ESAB-EU233
 *      HUKI-280 190709 VAIDJZ      Hybris, basket orders from Hybris to be refreshed.
 *  HUKI-280-001 190710 VAIDJZ      Line Mismatch, Pricing Issue Fix
 *    HM3LIVE-59 200610 M3KHATPZ    OOHEAD dump log Issue
 *     PUNDEL001 240715 XJVAIDYA    Primary Production Dashboard development
 */

/**
 * <BR>
 * <B><FONT SIZE=+2>Hybris Basket Management</FONT></B><BR>
 * <BR>
 *
 * This class ...<BR>
 * <BR>
 *
 */
public class ZDB101 extends Batch {

	public void movexMain() {
		INIT();
		writeZDB100();
		SETLR(); // A
		return;
	}
	public void writeZDB100()
	{
		String StandardDB = "M3FDB"+ getCurrentDatabaseFromCurrentSystemComponent();
		//String CusDB = getCurrentSystemComponent() + "FDB" + getCurrentDatabaseFromCurrentSystemComponent(); 
		
		
String strQuery = "SELECT IDSUNO,IDSUNM,DRROUT,DRTX40,MWWHLO,MWWHNM,DCTRCA,DCTX40,M1.AGBANO,M2.AGATVA,MAX(M6.AGATVN),MAX(M12.AGATVN),M10.AGATVA,M11.AGATVA,M8.AGATVN,M9.AGATVN,ROUND((M8.AGATVN-M9.AGATVN)*100000,2),M7.AGATVN,SUM(MTTRQT),SUM(MTTRQT)-M7.AGATVN,SUM(MTTRQT)*0.002,	M13.AGATVA,M14.AGATVA FROM"+StandardDB+".MIATTR M1 WITH (NOLOCK)INNER JOIN"+StandardDB+".MIATTR M2 WITH (NOLOCK) ON M2.AGCONO = M1.AGCONO AND M2.AGITNO = M1.AGITNO AND M2.AGBANO = M1.AGBANO AND M2.AGATNR = M1.AGATNR AND M2.AGATID = 'FECHA' INNER JOIN"+StandardDB+".MIATTR M3 WITH (NOLOCK) ON M3.AGCONO = M1.AGCONO AND M3.AGITNO = M1.AGITNO AND M3.AGBANO = M1.AGBANO AND M3.AGATNR = M1.AGATNR AND M3.AGATID = 'PLANCHADA'	INNER JOIN"+StandardDB+".MIATTR M4 WITH (NOLOCK) ON M4.AGCONO = M1.AGCONO AND M4.AGITNO = M1.AGITNO AND M4.AGBANO = M1.AGBANO AND M4.AGATNR = M1.AGATNR AND M4.AGATID = 'TRANSPORTISTA'	INNER JOIN"+StandardDB+".MIATTR M5 WITH (NOLOCK) ON M5.AGCONO = M1.AGCONO AND M5.AGITNO = M1.AGITNO AND M5.AGBANO = M1.AGBANO AND M5.AGATNR = M1.AGATNR AND M5.AGATID = 'VEHICULO' INNER JOIN"+StandardDB+".MIATTR M6 WITH (NOLOCK) ON M6.AGCONO = M1.AGCONO AND M6.AGITNO = M1.AGITNO AND M6.AGBANO = M1.AGBANO AND M6.AGATNR = M1.AGATNR AND M6.AGATID = 'KM_REALES' INNER JOIN"+StandardDB+".MIATTR M7 WITH (NOLOCK) ON M7.AGCONO = M1.AGCONO AND M7.AGITNO = M1.AGITNO AND M7.AGBANO = M1.AGBANO AND M7.AGATNR = M1.AGATNR AND M7.AGATID = 'LTS_REMITO'	INNER JOIN "+StandardDB+".MIATTR M8 WITH (NOLOCK) ON M8.AGCONO = M1.AGCONO AND M8.AGITNO = M1.AGITNO AND M8.AGBANO = M1.AGBANO AND M8.AGATNR = M1.AGATNR AND M8.AGATID = 'KG_ENTRADA' INNER JOIN "+StandardDB+".MIATTR M9 WITH (NOLOCK) ON M9.AGCONO = M1.AGCONO AND M9.AGITNO = M1.AGITNO AND M9.AGBANO = M1.AGBANO AND M9.AGATNR = M1.AGATNR AND M9.AGATID = 'KG_SALIDA' INNER JOIN "+StandardDB+".MIATTR M10 WITH (NOLOCK) ON M10.AGCONO = M1.AGCONO AND M10.AGITNO = M1.AGITNO AND M10.AGBANO = M1.AGBANO AND M10.AGATNR = M1.AGATNR AND M10.AGATID = 'FECHA_ENTRADA' INNER JOIN "+StandardDB+".MIATTR M11 WITH (NOLOCK) ON M11.AGCONO = M1.AGCONO AND M11.AGITNO = M1.AGITNO AND M11.AGBANO = M1.AGBANO AND M11.AGATNR = M1.AGATNR AND M11.AGATID = 'FECHA_SALIDA'	INNER JOIN "+StandardDB+".MIATTR M12 WITH (NOLOCK) ON M12.AGCONO = M1.AGCONO AND M12.AGITNO = M1.AGITNO AND M12.AGBANO = M1.AGBANO AND M12.AGATNR = M1.AGATNR AND M12.AGATID = 'KM_ESTANDAR' INNER JOIN "+StandardDB+".MIATTR M13 WITH (NOLOCK) ON M13.AGCONO = M1.AGCONO AND M13.AGITNO = M1.AGITNO AND M13.AGBANO = M1.AGBANO AND M13.AGATNR = M1.AGATNR AND M13.AGATID = 'DOMCAMION'	INNER JOIN "+StandardDB+".MIATTR M14 WITH (NOLOCK) ON M14.AGCONO = M1.AGCONO AND M14.AGITNO = M1.AGITNO AND M14.AGBANO = M1.AGBANO AND M14.AGATNR = M1.AGATNR AND M14.AGATID = 'DOMACOPLADO' INNER JOIN "+StandardDB+".CIDMAS WITH (NOLOCK) ON IDCONO = M1.AGCONO AND IDSUNO = M4.AGATVA INNER JOIN "+StandardDB+".DROUTE WITH (NOLOCK) ON DRCONO = M1.AGCONO AND DRROUT = M3.AGATVA AND DRSDES = '001'	INNER JOIN "+StandardDB+".MITWHL WITH (NOLOCK) ON MWCONO = M1.AGCONO AND MWWHLO = M1.AGATVA	INNER JOIN "+StandardDB+".DCARRI WITH (NOLOCK) ON DCCONO = M1.AGCONO AND DCTRCA = M5.AGATVA	INNER JOIN "+StandardDB+".MILOMA WITH (NOLOCK) ON LMCONO = M1.AGCONO AND LMATNR = M1.AGATNR	LEFT OUTER JOIN "+StandardDB+".MITTRA WITH (NOLOCK) ON MTCONO = M1.AGCONO AND MTITNO = M1.AGITNO AND MTBANO = M1.AGBANO AND MTTTYP = 40	WHERE M1.AGCONO = DCCONO AND M1.AGITNO = 'MP002210001' 	AND M1.AGATID = 'DESTINO '	AND M2.AGATVA <> 0 AND M2.AGATVA BETWEEN '20230617' AND '20230630' GROUP BY IDSUNO, IDSUNM, DRROUT, DRTX40, MWWHLO, MWWHNM, DCTRCA, DCTX40, M1.AGBANO, M7.AGATVN, M2.AGATVA, M8.AGATVN, M9.AGATVN, M10.AGATVA, M11.AGATVA, M12.AGATVA, M13.AGATVA, M14.AGATVA, M1.AGATNR, M2.AGATNR, M3.AGATNR, M4.AGATNR, M5.AGATNR, M6.AGATNR, M7.AGATNR, M8.AGATNR, M9.AGATNR, M10.AGATNR, M11.AGATNR, M12.AGATNR, M13.AGATNR, M14.AGATNR HAVING SUM(MTTRQT) <> 0 ORDER BY IDSUNM, DRTX40, MWWHNM, DCTX40, M1.AGBANO";
int nrOfRecords = 10; 	//number of records to retrieved
/*if(ZTYPE.getNOFR() > 0)
{
	nrOfRecords = ZTYPE.getNOFR();
}*/
strQuery+=  " fetch first "+nrOfRecords+" rows only ";
int nr = 0;
try{
	boolean isFirstRec = false;
	for (MvxString record_string: session.SQL(strQuery, nrOfRecords)){
		if(record_string == null){	//end of record
			break;
		}
		if(!isFirstRec){
			String[] columns = record_string.toString().split("\t");
			DASHB.setSUNO().moveLeftPad(columns[0].toString().trim());
			DASHB.setSUNM().moveLeftPad(columns[1].toString().trim());
			DASHB.setROUT().moveLeftPad(columns[2].toString().trim());
			DASHB.setTX40().moveLeftPad(columns[3].toString().trim());
			DASHB.setWHLO().moveLeftPad(columns[4].toString().trim());
			DASHB.setWHNM().moveLeftPad(columns[5].toString().trim());
			DASHB.setTRCA().moveLeftPad(columns[6].toString().trim());
			DASHB.setTX402().moveLeftPad(columns[7].toString().trim());
			DASHB.setBANO().moveLeftPad(columns[8].toString().trim());
			DASHB.setATVA().moveLeftPad(columns[9].toString().trim());
			// this.PXDCCD = ITAUN.getDCCD(); 	
	         this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[10].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setTRQT(this.PXNUM);
			
			 this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[11].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setKTVN(this.PXNUM);
			
			 this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[12].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setKETN(this.PXNUM);
			
			DASHB.setFTVA().moveLeftPad(columns[13].toString().trim());
			DASHB.setFSVA().moveLeftPad(columns[14].toString().trim());
			
			 this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[15].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setKTV1(this.PXNUM);
			
			this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[16].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setKTV2(this.PXNUM);
			
			this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[17].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setRTVN(this.PXNUM);
			
			this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[18].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setLTVN(this.PXNUM);
			
			this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[19].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setLRQT(this.PXNUM);
			
			this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[20].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setDRQT(this.PXNUM);
			
			this.PXFLDD = 9; 	 	
	         this.PXEDTC = '4';  	
	         this.PXDCFM = LDAZD.DCFM;  	
	         this.PXNUM = 0d; 	 	
	         this.PXALPH.clear(); 	 	
	         this.PXALPH.moveRight(columns[20].toString().trim());  	
	         SRCOMNUM.COMNUM();  	
			DASHB.setTTQT(this.PXNUM);
			
			DASHB.setDTVA().moveLeftPad(columns[22].toString().trim());
			DASHB.setDOVA().moveLeftPad(columns[23].toString().trim());
			
			
		}
	}
}catch (Exception e) {
	 e.printStackTrace();
}
	}
	public String getCurrentDatabaseFromCurrentSystemComponent() {
		MNCOC.setCOCO().moveLeftPad(getCurrentSystemComponent());
		if (MNCOC.CHAIN("00", MNCOC.getKey("00"))) {
			return MNCOC.getDBL1().substring(6, 9).toString().trim();
		} else {
			return "PRD";
		}
	}
	public MvxString getCurrentSystemComponent() {
		/* In case of failure, return empty */

	//	XXSYCO.clear();
		/* Find the current system configuration */
		MNDIV.setCONO(LDAZD.CONO);
		MNDIV.setDIVI().moveLeftPad(LDAZD.DIVI);
		if (!MNDIV.CHAIN("00", MNDIV.getKey("00"))) {
			//return XXSYCO;
		}
		/* Blank library means standard component */
		if (MNDIV.getLLID().isBlank()) {
			XXSYCO.moveLeftPad("MVX");
			return XXSYCO;
		}
		/* Find the current system component */
		MNSYC.setENCO().moveLeftPad(MNDIV.getLLID());
		if (!MNSYC.CHAIN("00", MNSYC.getKey("00"))) {
			return XXSYCO;
		}
		XXSYCO.moveLeftPad(MNSYC.getCOC1());
		return XXSYCO;
	}


	/**
	 * SETLR - End of program
	 */
	public void SETLR() {
		INLR = true;
		super.SETLR(INLR);
	}

	public void INIT() {
		// SYPAR.setDIVI().clear();
		// }
		this.PXDIVI.clear();
		JBCMD.setDIVI().clear();
		// Proformabas
		JBCMD.setBJLI().moveLeft("99");
		// IN91 = !JBCMD.CHAIN("00",JBCMD.getKey("00",2));
		IN91 = !JBCMD.CHAIN("00", KJBCMD()); // A
		if (!IN91) {
			ZDB100DS.setZDB100DS().moveLeft(JBCMD.getQCMD());
		} else {
			SETLR();
			return;
		}
	}
	// *ENTRY PARAMS
	public void unpackEntryParams(Object o) {// extract entry param
		MvxRecord mr = (MvxRecord) o;
		mr.reset();
		// mr.getString(P1BJNO); //A
		mr.getString(PXBJNO);
		// mr.getString(JBCMD.getBJNO());
	}

	public void returnEntryParams(Object o) {// return entry param
		MvxRecord mr = (MvxRecord) o;
		mr.reset();
		// mr.set(P1BJNO); //D
		mr.set(PXBJNO); // A
		// mr.set(JBCMD.getBJNO()); //A
	}

	public MvxRecord KJBCMD() {
		keyKJBCMD.reset();
		keyKJBCMD.set(PXBJNO);// *LIKE BJNO
		// keyKJBCMD.set(JBCMD.getBJNO());//*LIKE BJNO
		keyKJBCMD.set(JBCMD.getBJLI());// *LIKE BJLI
		return keyKJBCMD;
	}

	public sZDB100DS ZDB100DS = new sZDB100DS(this);
	public MvxRecord keyKJBCMD = new MvxRecord(40);
	public MvxString XXSYCO;
	

	public MvxString PXBJNO = new MvxString(18);// *LIKE XXA18
 

	public mvx.db.dta.CJBCMD JBCMD;
	public mvx.db.dta.CMNSYC MNSYC;
	public mvx.db.dta.CMNDIV MNDIV;
	public mvx.db.dta.CMNUSR MNUSR;
	public mvx.db.dta.CMNCOC MNCOC;
	public mvx.db.dta.ZDASHB DASHB;


	public void initMDB() {
		MNDIV = (mvx.db.dta.CMNDIV) getMDB("CMNDIV", MNDIV);
		DASHB = (mvx.db.dta.ZDASHB) getMDB("ZDASHB", DASHB);
		MNSYC = (mvx.db.dta.CMNSYC) getMDB("CMNSYC", MNSYC);
		MNUSR = (mvx.db.dta.CMNUSR) getMDB("CMNUSR", MNUSR);
		MNCOC = (mvx.db.dta.CMNCOC) getMDB("CMNCOC", MNCOC);
		JBCMD = (mvx.db.dta.CJBCMD) getMDB("CJBCMD", JBCMD);
		JBCMD.setAccessProfile("00", 'R');
		SYCAL = (mvx.db.dta.CSYCAL) getMDB("CSYCAL", SYCAL);
		SYCAL.setAccessProfile("00", 'R');
	}

	@SuppressWarnings({ "rawtypes", "unchecked" })
	public String getVarList(java.util.Vector v) {
		super.getVarList(v);
		v.addElement(ZDB100DS);
		v.addElement(DASHB);
		v.addElement(JBCMD);
		v.addElement(PXBJNO);
		v.addElement(SYCAL);
		return version;
	}

	public void clearInstance() {
		super.clearInstance();	}

	public String getVer() {
		return version;
	}

	public String getVersion() {
		return _version;
	} // �end of method getVersion

	public String getRelease() {
		return _release;
	} // �end of method getRelease

	public String getSpLevel() {
		return _spLevel;
	} // �end of method getSpLevel

	public String getSpNumber() {
		return _spNumber;
	} // �end of method getSpNumber

	public final static String _version = "15";
	public final static String _release = "1";
	public final static String _spLevel = "0";
	public final static String _spNumber ="MAK_XJVAIDYA_240712_08:56";
	public final static String _GUID = "DC03959E85DB11E898862C323CCD4821";
	public final static String _tempFixComment = "";
	public final static String _build = "000000000000566";
	public final static String _pgmName = "ZMM478";

	public String getGUID() {
		return _GUID;
	} // �end of method getGUID

	public String getTempFixComment() {
		return _tempFixComment;
	} // �end of method getTempFixComment

	public String getVersionInformation() {
		return _version + '.' + _release + '.' + _spLevel + ':' + _spNumber;
	} // �end of method getVersionInformation

	public String getBuild() {
		return (_version + _release + _build + "      " + _pgmName + "                                   ").substring(0,
				34);
	} // �end of method getBuild

   public String [][] getCustomerModification() {
      return _customerModifications;
   } // end of method [][] getCustomerModification()

   public final static String [][] _customerModifications={
      {"HUKI-263","190626","VAIDJZ","Hybris, cancelled carts also to be cancelled in M3 Hybris ticket ESAB-EU233"},
      {"HUKI-280","190709","VAIDJZ","Hybris, basket orders from Hybris to be refreshed."},
      {"HUKI-280-001","190710","VAIDJZ","Line Mismatch, Pricing Issue Fix"},
      {"HM3LIVE-59","200610","M3KHATPZ","OOHEAD dump log Issue"},
      {"PUNDEL001","240715","XJVAIDYA","Primary Production Dashboard development"}
   };
}