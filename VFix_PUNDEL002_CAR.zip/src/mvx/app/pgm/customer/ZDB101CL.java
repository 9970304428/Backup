/*
 ***************************************************************
 *                                                             *
 *                           NOTICE                            *
 *                                                             *
 *   THIS SOFTWARE IS THE PROPERTY OF AND CONTAINS             *
 *   CONFIDENTIAL INFORMATION OF INFOR AND/OR ITS AFFILIATES   *
 *   OR SUBSIDIARIES AND SHALL NOT BE DISCLOSED WITHOUT PRIOR  *
 *   WRITTEN PERMISSION. LICENSED CUSTOMERS MAY COPY AND       *
 *   ADAPT THIS SOFTWARE FOR THEIR OWN USE IN ACCORDANCE WITH  *
 *   THE TERMS OF THEIR SOFTWARE LICENSE AGREEMENT.            *
 *   ALL OTHER RIGHTS RESERVED.                                *
 *                                                             *
 *   (c) COPYRIGHT 2013 INFOR.  ALL RIGHTS RESERVED.           *
 *   THE WORD AND DESIGN MARKS SET FORTH HEREIN ARE            *
 *   TRADEMARKS AND/OR REGISTERED TRADEMARKS OF INFOR          *
 *   AND/OR ITS AFFILIATES AND SUBSIDIARIES. ALL RIGHTS        *
 *   RESERVED.  ALL OTHER TRADEMARKS LISTED HEREIN ARE         *
 *   THE PROPERTY OF THEIR RESPECTIVE OWNERS.                  *
 *                                                             *
 ***************************************************************
 */
package mvx.app.pgm.customer;

import mvx.app.common.*;
import mvx.util.*;

/*
 *Modification area - M3
 *Nbr            Date   User id     Description
 *99999999999999 999999 XXXXXXXXXX  x
 *Modification area - Business partner
 *Nbr            Date   User id     Description
 *99999999999999 999999 XXXXXXXXXX  x
 *Modification area - Customer
 *Nbr            Date   User id     Description
 *  PUNDEL001 240712 XJVAIDYA    Primary Production Dashboard development
 *  PUNDEL001-01 250527 XJVAIDYA    Dashboard development
 *     PUNDEL002 250530 XJVAIDYA    Primary Dashboard Development
 */

/**
 * <BR>
 * <B><FONT SIZE=+2>Primary Production Dashboard</FONT></B><BR>
 * <BR>
 *
 * This class ...<BR>
 * <BR>
 *
 */
public class ZDB101CL extends MvxCL {
	// MVX STANDARD: startJOB
	public boolean preBODY() {
		// Execute OVRPRTF
		if (!JBCMD.READE("00", EJBCMD())) {
			CLError();
		}
		if (JBCMD.getBJNO().NE(PXBJNO)) {
			CLError();
		}
		return true;
	}

	// MVX STANDARD: startLIST
	public boolean BODY() {
		// Call list program
		if (jobCall("ZDB101")) {
			CLError();
		}
		CLSTEND();
		return true;
	}

	public boolean endLIST() {
		// Override superclass method
		return true;
	}

	// MVX STANDARD: endJOB
	// MVX STANDARD: stdERROR
	// instance variables
	public void returnEntryParams(Object o) {// return entry param
		MvxRecord mr = (MvxRecord) o;
		mr.reset();
		mr.set(PXBJNO);
	}

	public void unpackEntryParams(Object o) {// extract entry param
		MvxRecord mr = (MvxRecord) o;
		mr.reset();
		mr.getString(PXBJNO);
	}

	public String getVersion() {
		return _version;
	}

	public String getRelease() {
		return _release;
	}

	public String getSpLevel() {
		return _spLevel;
	}

	public String getSpNumber() {
		return _spNumber;
	}

	public final static String _version = "15";
	public final static String _release = "1";
	public final static String _spLevel = "0";
	public final static String _spNumber ="MAK_XJVAIDYA_250527_09:58";
	public final static String _GUID = "D0987B7E48E04581805C0D07A540ECB8";

	public final static String _tempFixComment = "";

	public final static String _build = "000000000000001";

	public final static String _pgmName = "ZDB101CL";

	public String getGUID() {
		return _GUID;
	}

	public String getTempFixComment() {
		return _tempFixComment;
	}

	public String getVersionInformation() {
		return _version + '.' + _release + '.' + _spLevel + ':' + _spNumber;
	}

	public String getBuild() {
		return (_version + _release + _build + "      " + _pgmName + "                                   ").substring(0,
				34);
	}



   public String [][] getCustomerModification() {
      return _customerModifications;
   } // end of method [][] getCustomerModification()

   public final static String [][] _customerModifications={
      {"PUNDEL001","240712","XJVAIDYA","Primary Production Dashboard development"},
      {"PUNDEL001-01","250527","XJVAIDYA","Dashboard development"},
      {"PUNDEL002","250530","XJVAIDYA","Primary Dashboard Development"}
   };
}