import { Injectable } from "@angular/core";
import { CoreBase, IMIRequest, MIRecord } from "@infor-up/m3-odin";
import { MIService } from "@infor-up/m3-odin-angular";
import { IMIResponse } from "@infor-up/m3-odin";
import { SohoMessageService, SohoModalDialogService } from "ids-enterprise-ng";

@Injectable()
export class UpdatePOService extends CoreBase {

   constructor(private miService: MIService, private messageService: SohoMessageService,) {
      super('UpdatePOService');
   }

   async retrievePOline(puno: string, pnli: string) {
      var items = [];
      const request: IMIRequest = {
         program: 'PPS200MI',
         transaction: 'GetLine',
         maxReturnedRecords: 1,
         outputFields: ['PUNO', 'PNLI', 'ITNO', 'UCA1', 'UCA8', 'UCA9', 'UCA0', 'UDN5', 'UCT1', 'UID1', 'UID2', 'UID3', 'SUNO', 'PNLS']
      };

      const inputRecord: MIRecord = new MIRecord();
      inputRecord.setString('PUNO', puno);
      inputRecord.setString('PNLI', pnli);

      request.record = inputRecord;

      var response = await this.miService.execute(request).toPromise();

      console.log(response);
      return response.items[0];
   }
   async getData(suno: string) {
      var items = [];
      const request: IMIRequest = {
         program: 'CRS620MI',
         transaction: 'GetBasicData',
         maxReturnedRecords: 1,
         outputFields: ['SUNM']
      };

      const inputRecord: MIRecord = new MIRecord();
      inputRecord.setString('SUNO', suno);


      request.record = inputRecord;

      var response = await this.miService.execute(request).toPromise();

      console.log(response);
      return response.items[0];
   }

   async updatePOInformation(data: any) {
      console.log(data);
      let errMsg: any;
      const puno = !!data.PUNO && data.PUNO !== '' ? data.PUNO : '';
      const pnli = !!data.PNLI && data.PNLI !== '' ? data.PNLI : '';
      const uca1 = !!data.UCA1 && data.UCA1 !== '' ? data.UCA1 : '';
      const uca8 = !!data.UCA8 && data.UCA8 !== '' ? data.UCA8 : '';
      const uca9 = !!data.UCA9 && data.UCA9 !== '' ? data.UCA9 : '';
      const uca0 = !!data.UCA0 && data.UCA0 !== '' ? data.UCA0 : '';
      const udn5 = !!data.UDN5 && data.UDN5 !== '' ? data.UDN5 : '';
      const uct1 = !!data.UCT1 && data.UCT1 !== '' ? data.UCT1 : '';
      const uid1 = !!data.UID1 && data.UID1 !== '' ? data.UID1 : '';
      const uid2 = !!data.UID2 && data.UID2 !== '' ? data.UID2 : '0';
      const uid3 = !!data.UID3 && data.UID3 !== '' ? data.UID3 : '';
      const pnls = !!data.PNLS && data.PNLS !== '' ? data.PNLS : '';
      //const suno = !!data.SUNO && data.SUNO !== '' ? data.SUNO : '';
      //const sunm = !!data.SUNM && data.SUNM !== '' ? data.SUNM : '';

      const request: IMIRequest = {
         program: 'PPS200MI',
         transaction: 'UpdLine',
         outputFields: []
      };

      const inputRecord: MIRecord = new MIRecord();
      inputRecord.setString('PUNO', puno);
      inputRecord.setString('PNLI', pnli);
      //inputRecord.setString('SUNO', suno);
      inputRecord.setString('UCA1', uca1);//Adding UCA6 from import excel
      inputRecord.setString('UCA8', uca8);
      inputRecord.setString('UCA9', uca9);
      inputRecord.setString('UCA0', uca0);
      inputRecord.setString('UDN5', udn5);
      inputRecord.setString('UCT1', uct1);
      inputRecord.setString('UID1', uid1);
      inputRecord.setString('UID2', uid2);
      inputRecord.setString('UID3', uid3);
      inputRecord.setString('PNLS', pnls);




      request.record = inputRecord;
      //await this.miService.execute(request).toPromise();
      await this.miService.execute(request).toPromise().catch((error: IMIResponse) => {
         //    const buttons = [{ text: 'Ok', click: (e, modal) => { modal.close(); } }];
         //    //console.log('updated');
         //    this.messageService.error()
         //       .title('Any error occured')
         //       .message('Update failed.' + error.errorMessage)
         //       .buttons(buttons)
         //       .open();

         errMsg = error.errorMessage.toString();
         console.log(errMsg);
      });



      return errMsg;

   }
}
