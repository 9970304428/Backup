import { Component, OnInit } from '@angular/core';
import { CoreBase } from '@infor-up/m3-odin';
import { SohoToastService, SohoModalDialogRef, SohoModalDialogService } from 'ids-enterprise-ng';
import { UpdatePOService } from './update.service';
import { ActivatedRoute } from '@angular/router';
import { RouterTestingModule } from '@angular/router/testing';
import { RouterModule, Routes } from "@angular/router";
import { ThisReceiver } from '@angular/compiler';

@Component({
   selector: 'app-update',
   templateUrl: './update.component.html',
   styleUrls: ['./update.component.css'],
   // providers: [ActivatedRoute]
   providers: [UpdatePOService]
})
export class UpdateComponent extends CoreBase implements OnInit {

   public line: any = [];
   public result: any = [];
   ordernumber: string;
   orderline: string;
   data: any[];

   IBPUNO = "3000000073";
   IBPNLI = "10";

   idsunm: any;
   itno: string;
   puno: any;
   pnli: any;
   pnls: any;
   sunm: any;
   uca1: any;
   uca8: any;
   uca9: any;
   uca0: any;
   udn5: any;
   uct1: any;
   uid1: any;
   uid2: any;
   uid3: any;
   suno: any;
   checkbox1: boolean;
   checkbox2: boolean;
   message: any;
   diudn5: any;

   errorMessage: any;


   // route: any;


   constructor(private toastService: SohoToastService, private updatePOService: UpdatePOService) {
      super("UpdateComponent");
      console.log("inside constructor");
      this.loadData();

   }

   ngOnInit(): void {




      // this.route.queryParams
      //    .subscribe(params => {
      //       console.log(params);
      //       this.ordernumber = params.ordernumber;
      //       this.orderline = params.orderline;
      //       console.log("Order Number is ====> " + this.ordernumber);
      //       console.log("Order Line is ====> " + this.orderline);
      //    }
      //    );
      // this.loadData();
   }
   async loadData() {

      this.line = await this.updatePOService.retrievePOline(this.IBPUNO, this.IBPNLI);
      this.puno = this.line.PUNO;
      this.pnli = this.line.PNLI;
      this.itno = this.line.ITNO;
      this.suno = this.line.SUNO;
      this.uca1 = this.line.UCA1;
      this.uca8 = this.line.UCA8;
      this.uca9 = this.line.UCA9;
      this.uca0 = this.line.UCA0;
      this.udn5 = this.line.UDN5;
      this.pnls = this.line.PNLS;
      if (this.udn5 == '1') {
         this.udn5 = "YES";
      }
      else {
         this.udn5 = 0;
      }
      this.uct1 = this.line.UCT1;
      this.uid1 = this.convertDateTo(this.line.UID1);
      this.uid2 = this.convertDateTo(this.line.UID2);
      this.uid3 = this.convertDateTo(this.line.UID3);
      console.log(this.itno);
      //debugger;
      this.result = await this.updatePOService.getData(this.line.SUNO);
      this.sunm = this.result.SUNM;
   }

   async updateDataInPPS() {
      //this.data.push({this.puno, this.pnli, this.itno, this.suno, this.uca1, this.uca8, this.uca9, this.uca0, this.udn5, this.pnls, this.uct1, this.uid1, this.uid2, this.uid3});
      let data = [];

      if (this.udn5 == "YES") {
         this.diudn5 = '1';
      }
      else {
         this.diudn5 = '0';
      }
      const item = {
         PUNO: this.puno,
         PNLI: this.pnli,
         PNLS: this.pnls,
         UCA1: this.uca1,
         UCA8: this.uca8,
         UCA9: this.uca9,
         UCA0: this.uca0,
         UDN5: this.diudn5,
         UCT1: this.uct1,
         UID1: this.convertDateFrom(this.uid1),
         UID2: this.convertDateFrom(this.uid2),
         UID3: this.convertDateFrom(this.uid3),
      };

      data.push(item);
      console.log(item);

      this.errorMessage = await this.updatePOService.updatePOInformation(data[0]);
      debugger;
      console.log(this.errorMessage)

   }


   async showToast(position: SohoToastPosition = SohoToastService.TOP_RIGHT) {
      console.log("inside showToast==>")
      await this.updateDataInPPS();
      console.log(this.errorMessage)
      if (this.errorMessage == undefined) {
         this.toastService.show({ draggable: true, title: 'Entry Submitted', message: "Details updated successfully", position });
      }
      else {
         this.toastService.show({ draggable: true, title: 'Entry not Submitted', message: "Error occurred, details not updated", position });
      }
   }

   convertDateTo(date: string) {
      let cDate = ""
      if (date != "") {
         cDate = date.substring(0, 4) + '/' + date.substring(4, 6) + '/' + date.substring(6, 8)
      }
      return cDate;
   }
   convertDateFrom(date: string) {
      let cDate = ""
      if (date != "") {
         cDate = date.substring(0, 4) + date.substring(5, 7) + date.substring(8, 10)
      }
      return cDate;
   }

   changeCheckbox1(event) {
      if (event.target.checked == true) {
         this.checkbox1 = !this.checkbox1;
         this.uca1 = 'YES';
      }
      else {
         this.checkbox1 = !this.checkbox1;
         this.uca1 = '';

      }
   }
   changeCheckbox2(event) {
      if (event.target.checked == true) {
         this.checkbox2 = !this.checkbox2;
         this.udn5 = 'YES';
      }
      else {
         this.checkbox2 = !this.checkbox2;
         this.udn5 = '';

      }
   }

}
