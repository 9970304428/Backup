import { NgModule } from "@angular/core";
import { RouterModule, Routes } from "@angular/router";
import { UpdateComponent } from "./update/update.component";

const routes: Routes = [
   { path: 'main', component: UpdateComponent },
   { path: '', redirectTo: 'main', pathMatch: 'full' }      //default
];

@NgModule({
   imports: [RouterModule.forRoot(routes, { useHash: true })],
   exports: [RouterModule]
})
export class AppRoutingModule { }
